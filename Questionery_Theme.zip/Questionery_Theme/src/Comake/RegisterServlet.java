package Comake;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.persistence.Query;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.EntityManagerFactory;
/**
 * Servlet implementation class RegisterServlet
 */
public class RegisterServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() 
    {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings("unchecked")
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
	{
		    HttpSession session=req.getSession();
		    String email = req.getParameter("EMAIL");
		    String password = req.getParameter("PASSWORD");
		    EntityManagerFactory emf=Persistence.createEntityManagerFactory("Questionery_Theme");
		    EntityManager em=emf.createEntityManager();
		    em.getTransaction().begin();
		    //String select = "SELECT u FROM User u  WHERE u.EMAIL = :EMAIL and u.PASSWORD = :PASSWORD";
		    Query query = em.createQuery("SELECT u FROM User u  WHERE u.Email = '"+email+"' and u.Password = '"+password+"'");
		    if(query.getResultList().size() == 0)
		    {
		        System.out.println("Account does not exist!");
		    }
		    else
		    {
		    	query.getResultList().forEach(i -> {
		    		User user = (User) i;
			    	session.setAttribute("userid", user.getUserId());
		          });
		    	System.out.println("Login Success!");
		    	RequestDispatcher rd=req.getRequestDispatcher("Selection.jsp");
		    	rd.forward(req, res);		        
		    }
		    em.close();
		    emf.close();
	}
}