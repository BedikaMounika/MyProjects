package Comake;

import java.io.IOException;
import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 * Servlet implementation class QueryPushServlet
 */
@WebServlet("/QueryPushServlet")
public class QueryPushServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public QueryPushServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings({ "unchecked", "unused" })
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try 
		{
			      final HttpSession session = request.getSession();
			      ArrayList<Question> printitege = (ArrayList<Question>) session.getAttribute("printCategory");
			      String[] check=request.getParameterValues("checkques");
			      session.setAttribute("checkques", check);
			      //int userid = (int) session.getAttribute("userid");
			      EntityManagerFactory emf=Persistence.createEntityManagerFactory("Questionery_Theme");
	              EntityManager em=emf.createEntityManager();
			      for(int i=0;i<check.length;i++) {
			      int id = printitege.get(Integer.parseInt(check[i])).getUserId();  
			      String qus = printitege.get(Integer.parseInt(check[i])).getQuestions();
			      String opt1 = printitege.get(Integer.parseInt(check[i])).getOption1();
			      String opt2 = printitege.get(Integer.parseInt(check[i])).getOption2();
			      String opt3 = printitege.get(Integer.parseInt(check[i])).getOption3();
			      String opt4 = printitege.get(Integer.parseInt(check[i])).getOption4();
			      String opt5 = printitege.get(Integer.parseInt(check[i])).getOption5();
			      String crtans = printitege.get(Integer.parseInt(check[i])).getCorrectAnswer();
			      em.getTransaction().begin();
	              Query query = em.createNativeQuery("INSERT INTO calls.querypush (UserId, Questions, Option1, Option2,Option3, Option4, Option5, CorrectAnswer)"+"VALUES(?,?,?,?,?,?,?,?)");
	              query.setParameter(1, id);
	              query.setParameter(2, qus);
	              query.setParameter(3, opt1);
	              query.setParameter(4, opt2);
	              query.setParameter(5, opt3);
	              query.setParameter(6, opt4);
	              query.setParameter(7, opt5);
	              query.setParameter(8, crtans);
	              query.executeUpdate();
	              em.getTransaction().commit();
			      }
	         	  RequestDispatcher requestDispatcher = request.getRequestDispatcher("Preview.jsp");
		          requestDispatcher.forward(request, response);
		          em.close();
		          emf.close();	
		}
		catch (Exception e) 
	    {
				// TODO Auto-generated catch block
				e.printStackTrace();
		}  
	}
}