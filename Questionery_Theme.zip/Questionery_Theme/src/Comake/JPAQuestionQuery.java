package Comake;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class JPAQuestionQuery
{
	String qvalue ="Aptitude";
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("Questionery_Theme");
	EntityManager em=emf.createEntityManager();
	Query query=em.createQuery("Select from calls.question where question.category= :Aptitude" , Question.class).setParameter("Aptitude", qvalue);
	@SuppressWarnings("unchecked")
	List<Question> qus= query.getResultList();
}