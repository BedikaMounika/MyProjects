package Comake;

import java.io.Serializable;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: NumberOfQuestions
 *
 */
@Entity

public class NumberOfQuestions implements Serializable {

	   
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int SNo;
	private int UserId;
	private int NumberOfQuestions;
	private int Aptitude;
	private int Logical;
	private int Reasoning;
	private static final long serialVersionUID = 1L;

	public NumberOfQuestions() {
		super();
	}   
	public int getSNo() {
		return this.SNo;
	}

	public void setSNo(int SNo) {
		this.SNo = SNo;
	}   
	public int getUserId() {
		return this.UserId;
	}

	public void setUserId(int UserId) {
		this.UserId = UserId;
	}   
	
	public int getNumberOfQuestions() {
		return this.NumberOfQuestions;
	}

	public void setNumberOfQuestions(int NumberOfQuestions) {
		this.NumberOfQuestions = NumberOfQuestions;
	}   
	public int getAptitude() {
		return this.Aptitude;
	}

	public void setAptitude(int Aptitude) {
		this.Aptitude = Aptitude;
	}   
	public int getLogical() {
		return this.Logical;
	}

	public void setLogical(int Logical) {
		this.Logical = Logical;
	}   
	public int getReasoning() {
		return this.Reasoning;
	}

	public void setReasoning(int Reasoning) {
		this.Reasoning = Reasoning;
	}
   
}
