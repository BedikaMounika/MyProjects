package Comake;

import javax.persistence.*;

	
public class DataPush {

	@SuppressWarnings("unused")
	public void saveQueryPush(String printitege, String Questions, String Option1, String Option2, String Option3, String Option4, String Option5, String CorrectAnswer)
    {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("Questionery_Theme");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		QueryPush querypush=new QueryPush();
		querypush.setQuestions(Questions);
		querypush.setOption1(Option1);
		querypush.setOption2(Option2);
		querypush.setOption3(Option3);
		querypush.setOption4(Option4);
		querypush.setOption5(Option5);
		querypush.setCorrectAnswer(CorrectAnswer);
		boolean successful = false; 
		try 
		{
			em.persist(querypush);
			em.getTransaction().commit();
			emf.close(); 
			successful=true;
		}
		catch(Exception e) {
		}
    }
}