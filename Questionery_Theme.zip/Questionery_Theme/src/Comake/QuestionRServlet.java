package Comake;

import java.io.IOException;
import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 * Servlet implementation class QuestionRServlet
 */
@WebServlet("/QuestionRServlet")
public class QuestionRServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public QuestionRServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings({ "unchecked", "unused" })
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int val=0;
		int totalquestions= Integer.parseInt(request.getParameter("questions"));
		int aptitude= Integer.parseInt(request.getParameter("aptitude"));
		int logical= Integer.parseInt(request.getParameter("logical"));
		int Reasoning= Integer.parseInt(request.getParameter("Reasoning"));
		try 
		{
			HttpSession session=request.getSession();
			String result=null;
		  if(aptitude+logical+Reasoning==totalquestions)
		  {	
			String rvalue ="Reasoning";
			EntityManagerFactory emf=Persistence.createEntityManagerFactory("Questionery_Theme");
			EntityManager em=emf.createEntityManager();
			Query query=em.createQuery("Select r FROM Question r WHERE r.Category= '"+rvalue+"'");
			ArrayList<Question> rqus = new ArrayList<>();
			
				query.getResultList().forEach(rl -> {
					rqus.add((Question) rl);
				});
			session.setAttribute("printCategory", rqus);
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("/ViewReas.jsp");
			requestDispatcher.forward(request, response);
		  }
		  else
		  {
			RequestDispatcher rd=request.getRequestDispatcher("NumberOfQuestions.jsp");
			rd.include(request,response);	
		  }
		} 
		catch (Exception e) 
	    {
				// TODO Auto-generated catch block
				e.printStackTrace();
		}
	}
}