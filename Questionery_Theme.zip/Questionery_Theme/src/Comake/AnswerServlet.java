package Comake;

import java.io.IOException;
import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 * Servlet implementation class AnswerServlet
 */
@WebServlet("/AnswerServlet")
public class AnswerServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AnswerServlet() 
    {
        super();
        // TODO Auto-generated constructor stub
    }
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings({"unchecked", "unused" })
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try 
		{
			      HttpSession session = request.getSession();
			      ArrayList<String> ido = new ArrayList<String>();
			      String[] ids=(String[]) session.getAttribute("checkques");
			     //  = ("checkoption1");
			     // System.out.println(abc[0]);
			      for (int i=0; i<ids.length;i++)
			      {
			    	  String[] abc = request.getParameterValues("checkoption"+i);
			    	//System.out.println(abc[0].toString());
			    	ido.add(abc[0].toString());
			    	//System.out.println((ido.size())); 
			      }
			      ArrayList<Question> printitege = (ArrayList<Question>) session.getAttribute("printCategory");
			      //String[] checkoption = (String[]) session.getAttribute("checkoption"+i);
			      EntityManagerFactory emf=Persistence.createEntityManagerFactory("Questionery_Theme");
                  EntityManager em=emf.createEntityManager();
                  for(int i=0;i<ids.length;i++) {
                	  int id = printitege.get(Integer.parseInt(ids[i])).getUserId();  
                	  String crtans = printitege.get(Integer.parseInt(ids[i])).getCorrectAnswer();
                	  String userans = null;
                	  if(Integer.parseInt(ido.get(i)) == 1)
                		  userans = printitege.get(Integer.parseInt(ids[i])).getOption1();
                	  else if(Integer.parseInt(ido.get(i)) == 2)
                		  userans = printitege.get(Integer.parseInt(ids[i])).getOption2();
                	  else if(Integer.parseInt(ido.get(i)) == 3)
                		  userans = printitege.get(Integer.parseInt(ids[i])).getOption3();
                	  else if(Integer.parseInt(ido.get(i)) == 4)
                		  userans = printitege.get(Integer.parseInt(ids[i])).getOption4();
                	  else if(Integer.parseInt(ido.get(i)) == 5)
                		  userans = printitege.get(Integer.parseInt(ids[i])).getOption5();
                	  em.getTransaction().begin();
	              Query query = em.createNativeQuery("INSERT INTO calls.answer (USERID, CORRECTANSWER, USERANSWER)"+"VALUES(?,?,?)");
	              query.setParameter(1, id);
	              query.setParameter(2, crtans);
	              query.setParameter(3, userans);
	              query.executeUpdate();
	              em.getTransaction().commit();
		  }
                  em.close();
		          emf.close();	
                  System.out.println("Success!");
				  RequestDispatcher requestDispatcher = request.getRequestDispatcher("AnswerPush.jsp");
				  requestDispatcher.forward(request, response);   
		}
		catch (Exception e) 
	    {
				// TODO Auto-generated catch block
				e.printStackTrace();
		}  
	}
}