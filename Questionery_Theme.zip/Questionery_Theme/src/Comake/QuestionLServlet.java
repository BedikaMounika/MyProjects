package Comake;

import java.io.IOException;
import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 * Servlet implementation class QuestionLServlet
 */
@WebServlet("/QuestionLServlet")
public class QuestionLServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public QuestionLServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings({ "unchecked", "unused" })
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int val=0;
		int totalquestions= Integer.parseInt(request.getParameter("questions"));
		int aptitude= Integer.parseInt(request.getParameter("aptitude"));
		int logical= Integer.parseInt(request.getParameter("logical"));
		int Reasioning= Integer.parseInt(request.getParameter("Reasioning"));
		try 
		{
			HttpSession session=request.getSession();
			String result=null;
		  if(aptitude+logical+Reasioning==totalquestions)
		  {	
			String lvalue ="Logical";
			EntityManagerFactory emf=Persistence.createEntityManagerFactory("Questionery_Theme");
			EntityManager em=emf.createEntityManager();
			Query query=em.createQuery("Select l FROM Question l WHERE l.Category= '"+lvalue+"'");
			ArrayList<Question> lqus = new ArrayList<>();
			query.getResultList().forEach(rl -> {
			lqus.add((Question) rl);
			});
			session.setAttribute("printCategory", lqus);
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("/ViewLog.jsp");
			requestDispatcher.forward(request, response);
		  }
		  else
		  {
			RequestDispatcher rd=request.getRequestDispatcher("NumberOfQuestions.jsp");
			rd.include(request,response);	
		  }
		} 
		catch (Exception e) 
	    {
				// TODO Auto-generated catch block
				e.printStackTrace();
		}
	}
}