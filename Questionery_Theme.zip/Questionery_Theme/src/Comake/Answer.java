package Comake;

import java.io.Serializable;
import java.lang.String;
import javax.persistence.*;
/**
 * Entity implementation class for Entity: Answer
 *
 */
@Entity

public class Answer implements Serializable {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int SNo;   
	private int UserId;
	private String CorrectAnswer;
	private String UserAnswer;
	private static final long serialVersionUID = 1L;

	public Answer() {
		super();
	}   
	public int getSNo() {
		return this.SNo;
	}

	public void setSNo(int SNo) {
		this.SNo = SNo;
	}   
	public int getUserId() {
		return this.UserId;
	}

	public void setUserId(int UserId) {
		this.UserId = UserId;
	}   
	public String getCorrectAnswer() {
		return this.CorrectAnswer;
	}

	public void setCorrectAnswer(String CorrectAnswer) {
		this.CorrectAnswer = CorrectAnswer;
	}   
	public String getUserAnswer() {
		return this.UserAnswer;
	}

	public void setUserAnswer(String UserAnswer) {
		this.UserAnswer = UserAnswer;
	} 
}
