package Comake;

import java.io.IOException;
import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class QueryPushServlet1
 */
@WebServlet("/QueryPushServlet1")
public class QueryPushServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public QueryPushServlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings({ "unused", "unchecked" })
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try 
		{
			      final HttpSession session = request.getSession();
			      ArrayList<Question> printitege = (ArrayList<Question>) session.getAttribute("printCategory");
			      ArrayList<Question> printitl = (ArrayList<Question>) session.getAttribute("printCategory");
			      ArrayList<Question> printitr = (ArrayList<Question>) session.getAttribute("printCategory");
			      String[] check=request.getParameterValues("checkques");
			      String[] check1=request.getParameterValues("checkquesl");
			      String[] check2=request.getParameterValues("checkquesr");
			       {
			      }
			      session.setAttribute("checkques", check);
			      session.setAttribute("lqueslist",printitl);
			      session.setAttribute("rqueslist",printitr);
			      //int userid = (int) session.getAttribute("userid");
			      EntityManagerFactory emf=Persistence.createEntityManagerFactory("Questionery_Theme");
	              EntityManager em=emf.createEntityManager();
			      for(int i=0;i<check.length;i++) {
			      int id = printitege.get(Integer.parseInt(check[i])).getUserId();  
			      String qus = printitege.get(Integer.parseInt(check[i])).getQuestions();
			      String opt1 = printitege.get(Integer.parseInt(check[i])).getOption1();
			      String opt2 = printitege.get(Integer.parseInt(check[i])).getOption2();
			      String opt3 = printitege.get(Integer.parseInt(check[i])).getOption3();
			      String opt4 = printitege.get(Integer.parseInt(check[i])).getOption4();
			      String opt5 = printitege.get(Integer.parseInt(check[i])).getOption5();
			      String crtans = printitege.get(Integer.parseInt(check[i])).getCorrectAnswer();
			      int id1 = printitl.get(Integer.parseInt(check[i])).getUserId();  
			      String qus1 = printitl.get(Integer.parseInt(check[i])).getQuestions();
			      String opt11 = printitl.get(Integer.parseInt(check[i])).getOption1();
			      String opt21 = printitl.get(Integer.parseInt(check[i])).getOption2();
			      String opt31 = printitl.get(Integer.parseInt(check[i])).getOption3();
			      String opt41= printitl.get(Integer.parseInt(check[i])).getOption4();
			      String opt51 = printitl.get(Integer.parseInt(check[i])).getOption5();
			      String crtans1 = printitl.get(Integer.parseInt(check[i])).getCorrectAnswer();
			      int id2 = printitr.get(Integer.parseInt(check[i])).getUserId();  
			      String qus2 = printitr.get(Integer.parseInt(check[i])).getQuestions();
			      String opt12 = printitr.get(Integer.parseInt(check[i])).getOption1();
			      String opt22 = printitr.get(Integer.parseInt(check[i])).getOption2();
			      String opt32 = printitr.get(Integer.parseInt(check[i])).getOption3();
			      String opt42 = printitr.get(Integer.parseInt(check[i])).getOption4();
			      String opt52 = printitr.get(Integer.parseInt(check[i])).getOption5();
			      String crtans2 = printitr.get(Integer.parseInt(check[i])).getCorrectAnswer();
			      em.getTransaction().begin();
	              Query query = em.createNativeQuery("INSERT INTO calls.querypush (UserId, Questions, Option1, Option2,Option3, Option4, Option5, CorrectAnswer)"+"VALUES(?,?,?,?,?,?,?,?)");
	              Query query1 = em.createNativeQuery("INSERT INTO calls.querypush (UserId, Questions, Option1, Option2,Option3, Option4, Option5, CorrectAnswer)"+"VALUES(?,?,?,?,?,?,?,?)");
	              Query query2 = em.createNativeQuery("INSERT INTO calls.querypush (UserId, Questions, Option1, Option2,Option3, Option4, Option5, CorrectAnswer)"+"VALUES(?,?,?,?,?,?,?,?)");
	              query.setParameter(1, id);
	              query.setParameter(2, qus);
	              query.setParameter(3, opt1);
	              query.setParameter(4, opt2);
	              query.setParameter(5, opt3);
	              query.setParameter(6, opt4);
	              query.setParameter(7, opt5);
	              query.setParameter(8, crtans);
	              query1.setParameter(1, id1);
	              query1.setParameter(2, qus1);
	              query1.setParameter(3, opt11);
	              query1.setParameter(4, opt21);
	              query1.setParameter(5, opt31);
	              query1.setParameter(6, opt41);
	              query1.setParameter(7, opt51);
	              query1.setParameter(8, crtans1);
	              query2.setParameter(1, id2);
	              query2.setParameter(2, qus2);
	              query2.setParameter(3, opt12);
	              query2.setParameter(4, opt22);
	              query2.setParameter(5, opt32);
	              query2.setParameter(6, opt42);
	              query2.setParameter(7, opt52);
	              query2.setParameter(8, crtans2);
	              query.executeUpdate();
	              query1.executeUpdate();
	              query2.executeUpdate();
	              em.getTransaction().commit();
			      }
	         	  RequestDispatcher requestDispatcher = request.getRequestDispatcher("Preview1.jsp");
		          requestDispatcher.forward(request, response);
		          em.close();
		          emf.close();	
		}
		catch (Exception e) 
	    {
				// TODO Auto-generated catch block
				e.printStackTrace();
		}  
	}
}