package Comake;

import java.io.Serializable;
import java.lang.String;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: Selection
 *
 */
@Entity

public class Selection implements Serializable {

	   
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int SNo;
	private int UserId;
	private String Type;
	private static final long serialVersionUID = 1L;

	public Selection() {
		super();
	}   
	public int getSNo() {
		return this.SNo;
	}

	public void setSNo(int SNo) {
		this.SNo = SNo;
	}   
	public int getUserId() {
		return this.UserId;
	}

	public void setUserId(int UserId) {
		this.UserId = UserId;
	}   
	public String getType() {
		return this.Type;
	}

	public void setType(String Type) {
		this.Type = Type;
	}
   
}
