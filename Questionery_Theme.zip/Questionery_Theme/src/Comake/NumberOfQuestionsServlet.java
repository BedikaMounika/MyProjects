package Comake;

import java.io.IOException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class NumberOfQuestionsServlet
 */
@WebServlet("/NumberOfQuestionsServlet")
public class NumberOfQuestionsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NumberOfQuestionsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		int userid = (int)(session.getAttribute("userid"));
		int NumberOfQuestions = Integer.parseInt(request.getParameter("NumberOfQuestions"));
		int Aptitude = Integer.parseInt(request.getParameter("Aptitude"));
		int Logical = Integer.parseInt(request.getParameter("Logical"));
		int Reasoning = Integer.parseInt(request.getParameter("Reasoning"));
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("Questionery_Theme");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
        Query query = em.createNativeQuery("INSERT INTO questionsurvey.numberofquestions (UserId, NumberOfQuestions, Aptitude, Logical, Reasoning)"+"VALUES(?,?,?,?,?)");
          query.setParameter(1, userid);
          query.setParameter(2, NumberOfQuestions);
          query.setParameter(3, Aptitude);
          query.setParameter(4, Logical);
          query.setParameter(5, Reasoning);
          query.executeUpdate();
          em.getTransaction().commit();
          em.close();
          emf.close();
          RequestDispatcher requestdispatcher = request.getRequestDispatcher("Questions.jsp");
          requestdispatcher.forward(request, response);
		}
	}

