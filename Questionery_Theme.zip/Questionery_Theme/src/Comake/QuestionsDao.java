package Comake;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class QuestionsDao {
	
	public void addquestion(int SNo, int UserId, String Category, int NumberOfQuestions, String Questions, String Option1, String Option2, String Option3, String Option4, String Option5, String CorrectAnswer)
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("Questionery_Theme");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		Question que = new Question();
		que.setSNo(SNo);
		que.setUserId(UserId);
		que.setCategory(Category);
		que.setNumberOfQuestions(NumberOfQuestions);
		que.setQuestions(Questions);
		que.setOption1(Option1);
		que.setOption2(Option2);
		que.setOption3(Option3);
		que.setOption4(Option4);
		que.setOption5(Option5);
		que.setCorrectAnswer(CorrectAnswer);
		em.persist(que);
		em.getTransaction().commit();
		emf.close();
	}
}