package Comake;

import java.lang.String;
import javax.persistence.*;
/**
 * Entity implementation class for Entity: QueryPush
 *
 */
@Entity
public class QueryPush {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int SNo;
	private int UserId;
	private String Questions;
	private String Option1;
	private String Option2;
	private String Option3;
	private String Option4;
	private String Option5;
	private String CorrectAnswer;
	
	public QueryPush() {
		super();
	} 
	
	public int getSNo() {
		return this.SNo;
	}

	public void setSNo(int SNo) {
		this.SNo = SNo;
	} 
	
	public int getUserId() {
		return this.UserId;
	}

	public void setUserId(int UserId) {
		this.UserId = UserId;
	}  
	
	
	public String getQuestions() {
		return this.Questions;
	}

	public void setQuestions(String Questions) {
		this.Questions = Questions;
	}  
	
	public String getOption1() {
		return this.Option1;
	}

	public void setOption1(String Option1) {
		this.Option1 = Option1;
	}  
	
	public String getOption2() {
		return this.Option2;
	}

	public void setOption2(String Option2) {
		this.Option2 = Option2;
	} 
	
	public String getOption3() {
		return this.Option3;
	}

	public void setOption3(String Option3) {
		this.Option3 = Option3;
	} 
	
	public String getOption4() {
		return this.Option4;
	}

	public void setOption4(String Option4) {
		this.Option4 = Option4;
	}
	
	public String getOption5() {
		return this.Option5;
	}

	public void setOption5(String Option5) {
		this.Option5 = Option5;
	}   
	
	public String getCorrectAnswer() {
		return this.CorrectAnswer;
	}

	public void setCorrectAnswer(String CorrectAnswer) {
		this.CorrectAnswer = CorrectAnswer;
	}
}