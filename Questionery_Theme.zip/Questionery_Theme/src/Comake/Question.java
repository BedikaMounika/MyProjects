package Comake;

import java.lang.String;
import javax.persistence.*;
/**
 * Entity implementation class for Entity: Question
 *
 */
@Entity
public class Question {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int SNo;
	private int UserId;
	private String Category;
	private int NumberOfQuestions;
	private String Question;
	private String Option1;
	private String Option2;
	private String Option3;
	private String Option4;
	private String Option5;
	private String CorrectAnswer;
	
	public Question(int SNo, int UserId, String Category, int NumberOfQuestions, String Question, String Option1, String Option2, String Otion3, String Option4, String Option5, String CorrectAnswer) {
	}

	public Question() {
		// TODO Auto-generated constructor stub
	}

	
	public int getSNo() {
		return this.SNo;
	}

	public void setSNo(int SNo) {
		this.SNo = SNo;
	} 
	
	public int getUserId() {
		return this.UserId;
	}

	public void setUserId(int UserId) {
		this.UserId = UserId;
	}  
	
	public String getCategory() {
		return this.Category;
	}

	public void setCategory(String Category) {
		this.Category = Category;
	} 
	
	public int getNumberOfQuestions() {
		return this.NumberOfQuestions;
	}

	public void setNumberOfQuestions(int NumberOfQuestions) {
		this.NumberOfQuestions = NumberOfQuestions;
	}  
	
	public String getQuestion() {
		return this.Question;
	}

	public void setQuestion(String Question) {
		this.Question = Question;
	}
	
	public String getOption1() {
		return this.Option1;
	}

	public void setOption1(String Option1) {
		this.Option1 = Option1;
	}  
	
	public String getOption2() {
		return this.Option2;
	}

	public void setOption2(String Option2) {
		this.Option2 = Option2;
	}   
	public String getOption3() {
		return this.Option3;
	}

	public void setOption3(String Option3) {
		this.Option3 = Option3;
	} 
	
	public String getOption4() {
		return this.Option4;
	}

	public void setOption4(String Option4) {
		this.Option4 = Option4;
	}   
	
	public String getOption5() {
		return this.Option5;
	}

	public void setOption5(String Option5) {
		this.Option5 = Option5;
	}   
	
	public String getCorrectAnswer() {
		return this.CorrectAnswer;
	}

	public void setCorrectAnswer(String CorrectAnswer) {
		this.CorrectAnswer = CorrectAnswer;
	}
   
}
