package TestEnv;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
@Path("/environment")
public class TestEnvService
{

	@GET
	public String pingMe()
	{
	return "Congratulations,your environment has been setup";
	}
	
}
