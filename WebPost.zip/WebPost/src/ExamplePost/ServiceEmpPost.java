package ExamplePost;
import java.sql.SQLException;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
@Path("hello")
public class ServiceEmpPost 
{
	@POST
	@Path("/score")
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	@Produces("application/json")
	public String emp(GeneralEmployee ge) throws SQLException
	{
		EmployeeDao edao=new EmployeeDao();
		ObjectMapper objectMapper = new ObjectMapper();
    	//Set pretty printing of json
		objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
		String printitrge;
		String arrayToJson = null;
		try 
		{
		    
			printitrge = edao.saveEmployee(ge.getName(),ge.getDesignation(),ge.getDob(),ge.getJoiningDate(),ge.getEmail(),ge.getAddress()); 
			arrayToJson = objectMapper.writeValueAsString(printitrge);
		    
		}
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (JsonProcessingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return arrayToJson;
	}    	
}


