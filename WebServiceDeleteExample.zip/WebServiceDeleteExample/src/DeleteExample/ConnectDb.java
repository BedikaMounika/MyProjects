package DeleteExample;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class ConnectDb {

	static {
	     try {
	    	 Class.forName("com.mysql.cj.jdbc.Driver");
	    } catch (ClassNotFoundException e) {
	        throw new IllegalArgumentException("MySQL db driver isnot on classpath");
	    }
	}
	public static Connection getConnection() throws SQLException
	{
		 //return DriverManager.getConnection("jdbc:mysql://localhost/"+db_name+"?useSSL=false, user="+user_name+"&password="+password);
		 //return DriverManager.getConnection("jdbc:mysql://127.0.1:3306/'"+db_name+"'?useSSL=false&allowPublicKeyRetrieval=true", "'"+user_name+"'","'"+password+"'");
		return DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/mytrails?useSSL=false", "root","Abc@123456");
	}

}
