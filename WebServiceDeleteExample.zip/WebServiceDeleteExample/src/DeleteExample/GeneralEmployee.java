package DeleteExample;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
public class GeneralEmployee extends Employee{

	@JsonCreator
	public GeneralEmployee(@JsonProperty("emptype") String emptype, @JsonProperty("empno") String empno, @JsonProperty("name") String name,
	@JsonProperty("designation") String designation, @JsonProperty("dob") String dob, @JsonProperty("joiningdate") String joiningdate, 
	@JsonProperty("email") String email, @JsonProperty("Address") Address Address) {
		super(emptype,empno, name, designation, dob, joiningdate, email, Address);
		// TODO Auto-generated constructor stub
	}

}
