package DeleteExample;



public class Employee {

	public String emptype;
	public String empno;
	public String name;
	public String designation;
	public String dob;
	public String joiningDate;
	public String Email;
	Address Address;
	
	public Employee(String emptype,String empno, String name, String designation, String dob, String joiningDate, String email, Address Address) {
		super();
		this.emptype = emptype;
		this.empno = empno;
		this.name = name;
		this.designation = designation;
		this.dob = dob;
		this.joiningDate = joiningDate;
		this.Email = email;
		this.Address = Address;
	}
	
	public String getEmpType() {
		return emptype;
	}
	
	public void setEmpType(String emptype) {
		this.emptype = emptype;
	}
	public String getEmpno() {
		return empno;
	}


	public void setEmpno(String empno) {
		this.empno = empno;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getDesignation() {
		return designation;
	}


	public void setDesignation(String designation) {
		this.designation = designation;
	}


	public String getDob() {
		return dob;
	}


	public void setDob(String dob) {
		this.dob = dob;
	}


	public String getJoiningDate() {
		return joiningDate;
	}


	public void setJoiningDate(String joiningDate) {
		this.joiningDate = joiningDate;
	}


	public String getEmail() {
		return Email;
	}


	public void setEmail(String email) {
		this.Email = email;
	}
	
	public Address getAddress() {
		return Address;
	}
	
	
	public void setAddress(Address Address) {
		this.Address = Address;
	}
}
