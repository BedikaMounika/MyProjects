package Assignment5;
import java.io.BufferedReader;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Filereadsend {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String Filepath = "/Users/mounikab/Desktop/Document/Employees.csv";
		BufferedReader br = null;
		String line = "";
		String Splitbyvar = ",";
		int emptype, empno, Houseno;
		String name, designation,sdob , sjoiningDate, Email, sstartDate, stendDate, organisation, reportingTo, Street, Area , City , State;
		//Address Address = null;
		EmployeeListFactory elf = new EmployeeListFactory();
		try 
		{
			br = new BufferedReader(new FileReader(Filepath));
			while ((line = br.readLine())!= null)
			{
				String[] Employees = line.split(Splitbyvar);
				emptype = Integer.parseInt(Employees[0]);
				if(emptype == 1)
				{
					empno = Integer.parseInt(Employees[1]);
					name = Employees[2];
					designation = Employees[3];
					sdob = Employees[4];
					sjoiningDate = Employees[5];
					Email = Employees[6];
					Houseno = Integer.parseInt(Employees[7]);
					Street = Employees[8];
					Area = Employees[9];
					City = Employees[10];
			        State = Employees[11];
					Address gad1 = new Address(Houseno, Street, Area, City, State);
					
					elf.createList("LIST", emptype, empno, name, designation, sdob, sjoiningDate, Email, gad1);
				
					/*	System.out.println("GeneralEmployee");
					 System.out.println("Employee No.:"
				           		+ empno +"\n"
				           		+"Employee Name.:"+ name +"\n"
				           		+"Employee Designation:"+ designation +"\n"
				           		+"Employee DateOfbirth:"+sdob+"\n"
				           		+"Employee JoiningDate:"+sjoiningDate+"\n"
				           		+"Employee email:"+Email + "\n"
				           		+"Employee Address:" + Houseno + "," + Street + "," + Area + "," + City + "," + State +  "\n"); */
					 //elf.callEnumeration("LIST");
				}
				else if(emptype == 2)
				{
					empno = Integer.parseInt(Employees[1]);
					name = Employees[2];
					designation = Employees[3];
					sdob = Employees[4];
					sjoiningDate = Employees[5];
					Email = Employees[6];
					sstartDate = Employees[7];
					stendDate =Employees[8];
					organisation = Employees[9];
					Houseno = Integer.parseInt(Employees[10]);
					Street = Employees[11];
					Area = Employees[12];
					City = Employees[13];
					State = Employees[14];
					Address cad1 = new Address(Houseno, Street, Area, City, State);
					
					
                   elf.createList("LIST", emptype, empno, name, designation, sdob, sjoiningDate, Email, sstartDate, stendDate, organisation, cad1);					
					
				/*	System.out.println("ContractEmployee");
					System.out.println("Employee No.:"
			           		+ empno +"\n"
			           		+"Employee Name.:"+ name +"\n"
			           		+"Employee Designation:"+ designation +"\n"
			           		+"Employee DateOfbirth:"+sdob+"\n"
			           		+"Employee JoiningDate:"+sjoiningDate+"\n"
			           		+"Employee email:"+Email + "\n"
			           		+"Employee startdate:" + sstartDate + "\n"
			           		+ "Employee endDate:" + stendDate + "\n"
			           		+ "Employee Organisation:" + organisation + "\n"
			           		+"Employee Address:" + Houseno + "," + Street + "," + Area + "," + City + "," + State + "\n"); */
				}
				else if(emptype == 3)
				{
					empno = Integer.parseInt(Employees[1]);
					name = Employees[2];
					designation = Employees[3];
					sdob = Employees[4];
					sjoiningDate = Employees[5];
					Email = Employees[6];
					sstartDate = Employees[7];
					stendDate =Employees[8];
					reportingTo = Employees[9];
					Houseno = Integer.parseInt(Employees[10]);
					Street = Employees[11];
					Area = Employees[12];
					City = Employees[13];
					State = Employees[14];
					Address aad1 = new Address(Houseno, Street, Area, City, State);
					
					
					elf.createList("LIST", emptype, empno, name, designation, sdob, sjoiningDate, Email, sstartDate, stendDate, reportingTo, aad1);
					
					
					/* System.out.println("Apprentice");
					System.out.println("Employee No.:"
			           		+ empno +"\n"
			           		+"Employee Name.:"+ name +"\n"
			           		+"Employee Designation:"+ designation +"\n"
			           		+"Employee DateOfbirth:"+sdob+"\n"
			           		+"Employee JoiningDate:"+sjoiningDate+"\n"
			           		+"Employee email:"+Email + "\n"
			           		+"Employee startdate:" + sstartDate + "\n"
			           		+ "Employee endDate:" + stendDate + "\n"
			           		+ "Employee ReportingTo:" + reportingTo + "\n"
			           		+"Employee Address:" + Houseno + "," + Street + "," + Area + "," + City + "," + State + "\n"); */
				}
				else
					System.out.println("Enter valid Employee Type to insert");
			}
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}catch(IOException e)
		{
			e.printStackTrace();
		}
		finally 
		{
		if(br != null)
		{
			try {
				br.close();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
			elf.callEnumeration("LIST");
		}
		}
		
	}
	

}
