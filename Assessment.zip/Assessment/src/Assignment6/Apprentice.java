package Assignment6;
import java.time.LocalDate;



public class Apprentice extends Employee{

	public LocalDate startDate;
	public LocalDate endDate;
	public String reportingTo;
	

	public Apprentice(int emptype,int empno, String name, String designation, LocalDate dob, LocalDate joiningDate, String email, LocalDate startDate,
			LocalDate endDate, String reportingTo, Address Address) {
		super(emptype,empno, name, designation, dob, joiningDate, email, Address);
		// TODO Auto-generated constructor stub
		
		this.startDate = startDate;
		this.endDate = endDate;
		
		this.reportingTo = reportingTo;


}
	
	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public String getReportingTo() {
		return reportingTo;
	}

	public void setReportingTo(String reportingTo) {
		this.reportingTo = reportingTo;
	}
}
