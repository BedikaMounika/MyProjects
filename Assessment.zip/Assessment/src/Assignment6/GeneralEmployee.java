package Assignment6;
import java.time.LocalDate;



public class GeneralEmployee extends Employee {

	public GeneralEmployee(int emptype,int empno, String name, String designation, LocalDate dob, LocalDate joiningDate, String email, Address Address) {
		super(emptype,empno, name, designation, dob, joiningDate, email, Address);
		// TODO Auto-generated constructor stub
	}

}
