package Assignment6;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Testsql {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	try
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con= DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/mytrails?useSSL=false", "root","Abc@123456");
		String sql = "insert into generalemployee (empno,empname,designation,dob,joindate,email) values (102,'sai', 'Trainer', '1992-02-10','2018-06-25', 'sai92sk@live.com' )";
		Statement stmt  = con.createStatement();
        stmt.executeUpdate(sql, Statement.RETURN_GENERATED_KEYS);
		 ResultSet res = stmt.getGeneratedKeys();
		
		if(res.next())
			System.out.println(res.getInt(1));
		con.close();
	}
	catch(Exception e)
	{
		System.out.println(e);
	}

	}

}
