package Assignment6;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

public class EmployeeDao {
	
	
	
	@SuppressWarnings("finally")
	public Connection connectDbobj()
	{
	Connection con = null;
	try
	{
		 con= ConnectDb.getConnection();
			
	}
	catch(Exception e)
	{
		System.out.println(e);
	}

	finally
	{
		return con;
	}
	}
	@SuppressWarnings("finally")
	public int saveEmployee(String name, String designation, LocalDate dob, LocalDate joiningdate, String email, Address address) throws SQLException
   {
		
		int empno = 0;
		Connection gcon = null;
		gcon = connectDbobj();
		ResultSet res = null;
		PreparedStatement stmt = null;
		  try { 
			  String sql = "insert into generalemployee (empname,designation,dob,joiningdate,email) values (?,?,?,?,?)";
			  stmt = gcon.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
		   
			    stmt.setString(1, name);
				stmt.setString(2, designation);
				stmt.setObject(3, dob);
				stmt.setObject(4, joiningdate);
				stmt.setString(5, email);
				stmt.executeUpdate();
			
			
		    res = stmt.getGeneratedKeys();
			if(res.next())
				empno = res.getInt(1);
			addAddress(empno,address.Houseno,address.Street,address.Area,address.City,address.State);
			 
        }
       catch(Exception e)
		{
       	System.out.println(e);
	     }
		  finally {
			  if(!res.next())
				  res.close();
			  stmt.close();
			  gcon.close();
			  
        return empno;
    
		  }
	 }
	 public void saveContract(String name, String designation, LocalDate dob,LocalDate joiningDate, String email, LocalDate startDate, LocalDate endDate, String organisation, Address address) throws SQLException
	 {
		int empno = saveEmployee(name, designation, dob, joiningDate, email, address);
		Connection cecon = null;
		cecon = connectDbobj();
		PreparedStatement stmt = null;
		try
		{
			stmt = cecon.prepareStatement("insert into contractemployee (conempno,startdate,enddate,organisation) values (?,?,?,?)");
			stmt.setInt(1, empno);
			stmt.setObject(2, startDate);
			stmt.setObject(3, endDate);
			stmt.setString(4, organisation);
		    stmt.executeUpdate();
          
        }
       catch(Exception e)
		{
       	System.out.println(e);
	     }
		finally
		{
			stmt.close();
			cecon.close();
		}
	 }
	 public void saveApprentice(String name, String designation, LocalDate dob, LocalDate joiningDate, String email, LocalDate startDate, LocalDate endDate, String reportingTo, Address address) throws SQLException
	 {
		 int empno = saveEmployee(name, designation, dob, joiningDate, email, address);
		 Connection apcon = null;
		 apcon = connectDbobj();
		 PreparedStatement stmt = null;
			try
			{
				stmt = apcon.prepareStatement("insert into apprentice (apempno,startdate,enddate,reportingto) values (?,?,?,?)");
				stmt.setInt(1, empno);
				stmt.setObject(2, startDate);
				stmt.setObject(3, endDate);
				stmt.setString(4, reportingTo);
				stmt.executeUpdate();
	            
	         }
	        catch(Exception e)
			{
	        	System.out.println(e);
		     }
			finally
			{
				stmt.close();
				apcon.close();
			}
		
	  }
	 public void addAddress(int empno, int houseno, String street, String area, String city, String state) throws SQLException
	 {
		 Connection adcon = null;
		 adcon = connectDbobj();
		 PreparedStatement stmt = null;
		 try
			{
				stmt = adcon.prepareStatement("insert into address (addempno,houseno,street,area,city,state) values (?,?,?,?,?,?)");
			    stmt.setInt(1, empno);
			    stmt.setInt(2, houseno);
			    stmt.setString(3, street);
			    stmt.setString(4, area);
			    stmt.setString(5, city);
			    stmt.setString(6, state);
			    stmt.executeUpdate();
	            
	         }
	        catch(Exception e)
			{
	        	System.out.println(e);
		     }
		 finally
		 {
			 stmt.close();
			 adcon.close();
		 }
	 }
	 public void loadEmployee() throws SQLException
	 {
		 Connection loadcon = null;
		 loadcon = connectDbobj();
		 PreparedStatement stmt1 = null;
		 PreparedStatement stmt2 = null;
		 PreparedStatement stmt3 = null;
		 ResultSet res = null;
		 ResultSet contractres = null;
		 ResultSet apres = null;
		 int emptype, empno, Houseno;
			String name, designation,sdob , sjoiningDate, Email, sstartDate, stendDate, organisation, reportingTo, Street, Area , City , State;
		 try
			{
							       
			    String sql = "SELECT table1.empno,table1.empname,table1.designation, table1.dob,table1.joiningdate, table1.email, table2.houseno, table2.street, table2.area, table2.city, table2.state FROM \r\n"+
			            "(SELECT generalemployee.empno,generalemployee.empname,generalemployee.designation, generalemployee.dob,generalemployee.joiningdate, generalemployee.email \r\n" + 
			    		"FROM generalemployee\r\n" + 
			    		"WHERE generalemployee.empno NOT IN \r\n" + 
			    		"((SELECT conempno from contractemployee)\r\n" + 
			    		"UNION (SELECT apempno from apprentice))) table1\r\n" +
			    		"LEFT JOIN \r\n"+
			    		"(SELECT * FROM address ) table2\r\n"+
			    		"ON table1.empno = table2.addempno\r\n"+
			    		"ORDER BY table1.empno;";
			    stmt1 = loadcon.prepareStatement(sql);
			    res = stmt1.executeQuery();
			   
			    EmployeeListFactory elf = new EmployeeListFactory();
			    while(res.next())
			    {
			    emptype = 1;
			    empno = res.getInt(1);
			    name = res.getString(2);
			    designation = res.getString(3);
			    sdob = res.getString(4);
			    sjoiningDate = res.getString(5);
			    Email = res.getString(6);
			    Houseno = res.getInt(7);
			    Street = res.getString(8);
			    Area = res.getString(9);
			    City = res.getString(10);
			    State = res.getString(11);
			   Address gad1 = new Address(Houseno,Street,Area,City,State);
			    elf.createList("LIST", emptype, empno, name, designation, sdob, sjoiningDate, Email, gad1);
			  
			    }
			    
			    
			    String sql2 = "SELECT generalemployee.empno,generalemployee.empname,generalemployee.designation, generalemployee.dob,generalemployee.joiningdate, generalemployee.email, contractemployee.startdate,contractemployee.enddate, contractemployee.organisation,"
			    		+ "address.houseno, address.street, address.area, address.city, address.state\r\n" + 
			    		"FROM (generalemployee\r\n" + 
			    		"RIGHT JOIN contractemployee \r\n" + 
			    		"ON generalemployee.empno = contractemployee.conempno)\r\n" +
			    		"LEFT JOIN address\r\n"+
			    		"ON generalemployee.empno = address.addempno\r\n"+
			    		"ORDER BY contractemployee.conempno;";
			    stmt2 = loadcon.prepareStatement(sql2);
			    contractres = stmt2.executeQuery();
			  
			    while(contractres.next())
			    {
			    	emptype = 2;
			    	 empno = contractres.getInt(1);
					    name = contractres.getString(2);
					    designation = contractres.getString(3);
					    sdob = contractres.getString(4);
					    sjoiningDate = contractres.getString(5);
					    Email = contractres.getString(6);
					    sstartDate = contractres.getString(7);
					    stendDate = contractres.getString(8);
					    organisation = contractres.getString(9);
					    Houseno = contractres.getInt(10);
					    Street =contractres.getString(11);
					    Area = contractres.getString(12);
					    City = contractres.getString(13);
					    State = contractres.getString(14);
					   Address cad1 = new Address(Houseno,Street,Area,City,State);
					   elf.createList("LIST", emptype, empno, name, designation, sdob, sjoiningDate, Email, sstartDate, stendDate, organisation, cad1);
			    }
			    
			   
			    
				String sql3 = "SELECT generalemployee.empno,generalemployee.empname,generalemployee.designation, generalemployee.dob,generalemployee.joiningdate, generalemployee.email, apprentice.startdate,apprentice.enddate, apprentice.reportingto,"
						+ "address.houseno, address.street, address.area, address.city, address.state\r\n" + 
			    		"FROM (generalemployee\r\n" + 
			    		"RIGHT JOIN apprentice \r\n" + 
			    		"ON generalemployee.empno = apprentice.apempno)\r\n" +
			    		"LEFT JOIN address\r\n"+
			    		"ON generalemployee.empno = address.addempno\r\n"+
			    		"ORDER BY apprentice.apempno;";
				 stmt3 = loadcon.prepareStatement(sql3);
				 apres = stmt3.executeQuery();
			    
			    while(apres.next())
			    {
			    	emptype = 3;
			    	 empno = apres.getInt(1);
					    name = apres.getString(2);
					    designation = apres.getString(3);
					    sdob = apres.getString(4);
					    sjoiningDate = apres.getString(5);
					    Email = apres.getString(6);
					    sstartDate = apres.getString(7);
					    stendDate = apres.getString(8);
					    reportingTo = apres.getString(9);
					    Houseno = apres.getInt(10);
					    Street =apres.getString(11);
					    Area = apres.getString(12);
					    City = apres.getString(13);
					    State = apres.getString(14);
					   Address aad1 = new Address(Houseno,Street,Area,City,State);
					   elf.createList("LIST", emptype, empno, name, designation, sdob, sjoiningDate, Email, sstartDate, stendDate, reportingTo, aad1);
			    	
			    }
			    			    
			    //calling iterator on list to print data from database
			    elf.callIterator("LIST");
	         }
	        catch(Exception e)
			{
	        	System.out.println(e);
		     }
			 finally
			 {
				 if(!res.next())
				    	res.close();
				 if(!contractres.next())
				    	contractres.close();
				 if(!apres.next())
				    	apres.close();
				 stmt1.close();
				 stmt2.close();
				 stmt3.close();
				 loadcon.close();

			 }
	  }
	 
	 
}
