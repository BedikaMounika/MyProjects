package Assignment6;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;


public class Filereadtocoll {

	public static void main(String[] args) throws SQLException {
	
	String Filepath = "/Users/mounikab/Desktop/Document/Employees.csv";
	BufferedReader br = null;
	String line = "";
	String Splitbyvar = ",";
	int emptype, empno, Houseno;
	String name, designation,sdob , sjoiningDate, Email, sstartDate, stendDate, organisation, reportingTo, Street, Area , City , State;
	
	EmployeeListFactory elf = new EmployeeListFactory();
	
	//Address Address = null;
	
	
	
	try 
	{
		br = new BufferedReader(new FileReader(Filepath));
		while ((line = br.readLine())!= null)
		{
			String[] Employees = line.split(Splitbyvar);
			emptype = Integer.parseInt(Employees[0]);
			if(emptype == 1)
			{
				empno = Integer.parseInt(Employees[1]);
				name = Employees[2];
				designation = Employees[3];
				sdob = Employees[4];
				sjoiningDate = Employees[5];
				Email = Employees[6];
				Houseno = Integer.parseInt(Employees[7]);
				Street = Employees[8];
				Area = Employees[9];
				City = Employees[10];
		        State = Employees[11];
				Address gad1 = new Address(Houseno, Street, Area, City, State);
				
				elf.createList("LIST", emptype, empno, name, designation, sdob, sjoiningDate, Email, gad1);
			
				/*	System.out.println("GeneralEmployee");
				 System.out.println("Employee No.:"
			           		+ empno +"\n"
			           		+"Employee Name.:"+ name +"\n"
			           		+"Employee Designation:"+ designation +"\n"
			           		+"Employee DateOfbirth:"+sdob+"\n"
			           		+"Employee JoiningDate:"+sjoiningDate+"\n"
			           		+"Employee email:"+Email + "\n"
			           		+"Employee Address:" + Houseno + "," + Street + "," + Area + "," + City + "," + State +  "\n"); */
				 //elf.callEnumeration("LIST");
			}
			else if(emptype == 2)
			{
				empno = Integer.parseInt(Employees[1]);
				name = Employees[2];
				designation = Employees[3];
				sdob = Employees[4];
				sjoiningDate = Employees[5];
				Email = Employees[6];
				sstartDate = Employees[7];
				stendDate =Employees[8];
				organisation = Employees[9];
				Houseno = Integer.parseInt(Employees[10]);
				Street = Employees[11];
				Area = Employees[12];
				City = Employees[13];
				State = Employees[14];
				Address cad1 = new Address(Houseno, Street, Area, City, State);
				
				
               elf.createList("LIST", emptype, empno, name, designation, sdob, sjoiningDate, Email, sstartDate, stendDate, organisation, cad1);					
				
			/*	System.out.println("ContractEmployee");
				System.out.println("Employee No.:"
		           		+ empno +"\n"
		           		+"Employee Name.:"+ name +"\n"
		           		+"Employee Designation:"+ designation +"\n"
		           		+"Employee DateOfbirth:"+sdob+"\n"
		           		+"Employee JoiningDate:"+sjoiningDate+"\n"
		           		+"Employee email:"+Email + "\n"
		           		+"Employee startdate:" + sstartDate + "\n"
		           		+ "Employee endDate:" + stendDate + "\n"
		           		+ "Employee Organisation:" + organisation + "\n"
		           		+"Employee Address:" + Houseno + "," + Street + "," + Area + "," + City + "," + State + "\n"); */
			}
			else if(emptype == 3)
			{
				empno = Integer.parseInt(Employees[1]);
				name = Employees[2];
				designation = Employees[3];
				sdob = Employees[4];
				sjoiningDate = Employees[5];
				Email = Employees[6];
				sstartDate = Employees[7];
				stendDate =Employees[8];
				reportingTo = Employees[9];
				Houseno = Integer.parseInt(Employees[10]);
				Street = Employees[11];
				Area = Employees[12];
				City = Employees[13];
				State = Employees[14];
				Address aad1 = new Address(Houseno, Street, Area, City, State);
				
				
				elf.createList("LIST", emptype, empno, name, designation, sdob, sjoiningDate, Email, sstartDate, stendDate, reportingTo, aad1);
				
				
				/* System.out.println("Apprentice");
				System.out.println("Employee No.:"
		           		+ empno +"\n"
		           		+"Employee Name.:"+ name +"\n"
		           		+"Employee Designation:"+ designation +"\n"
		           		+"Employee DateOfbirth:"+sdob+"\n"
		           		+"Employee JoiningDate:"+sjoiningDate+"\n"
		           		+"Employee email:"+Email + "\n"
		           		+"Employee startdate:" + sstartDate + "\n"
		           		+ "Employee endDate:" + stendDate + "\n"
		           		+ "Employee ReportingTo:" + reportingTo + "\n"
		           		+"Employee Address:" + Houseno + "," + Street + "," + Area + "," + City + "," + State + "\n"); */
			}
			else
				System.out.println("Enter valid Employee Type to insert");
		}
	
		//iterating through employee list
		Iterator<Employee> storemp = elf.callIterator("LIST");
		
		//storing in respective databases
		
		EmployeeDao ed = new EmployeeDao();
		
		while(storemp.hasNext())
		{
			
			Employee employee = storemp.next();
			
			 if(employee instanceof GeneralEmployee)
			   {
				   	GeneralEmployee g1 = (GeneralEmployee) employee;
				   	ed.saveEmployee(g1.getName(),g1.getDesignation(), g1.getDob(), g1.getJoiningDate(), g1.getEmail(),g1.getAdress());
		     		
			   }
			  
			   else if (employee instanceof ContractEmployee)
			   {
				 
					   ContractEmployee c1 = (ContractEmployee) employee;
					   ed.saveContract(c1.getName(), c1.getDesignation(), c1.getDob(), c1.getJoiningDate(), c1.getEmail(), c1.getStartDate(), c1.getEndDate(), c1.getOrganisation(), c1.getAdress());
					 
			       		
				  }
			   else if (employee instanceof Apprentice)
			   {
				   
						Apprentice ap = (Apprentice) employee;
						ed.saveApprentice(ap.getName(), ap.getDesignation(), ap.getDob(), ap.getJoiningDate(), ap.getEmail(), ap.getStartDate(), ap.getEndDate(), ap.getReportingTo(), ap.getAdress());
			       		
			   }
						
			}
	}
	catch(FileNotFoundException e)
	{
		e.printStackTrace();
	}catch(IOException e)
	{
		e.printStackTrace();
	}
	finally 
	{
	if(br != null)
	{
		try {
			br.close();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
	}
		
		
		
		
	
	
	}
}