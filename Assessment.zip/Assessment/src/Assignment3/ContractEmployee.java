package Assignment3;
import java.time.LocalDate;
import java.time.Period;


public class ContractEmployee extends EmpAbs {

	public LocalDate startDate;
	public LocalDate endDate;
	public String organisation;

	public ContractEmployee(int empno, String name, String designation, LocalDate dob, LocalDate joiningDate,
			String email, LocalDate startDate, LocalDate endDate, String organisation , Address Address) {
		super(empno, name, designation, dob, joiningDate, email, Address);
		// TODO Auto-generated constructor stub
		
		this.startDate = startDate;
		this.endDate = endDate;
		this.organisation = organisation;
		
	}

	public ContractEmployee(EmpAbs Remp, LocalDate startDate, LocalDate endDate,String reportingTo) {
		super(Remp.empno, Remp.name,Remp.designation,Remp.dob,Remp.joiningDate,Remp.Email, Remp.Address);
		this.startDate = startDate;
		this.endDate = endDate;
		this.organisation= reportingTo;

	}
	
public String toString(){
		
		return this.getEmpno()+"_"+this.getStartDate()+"_"+this.getEndDate();	
		
	}
	
	public void showData(){
		System.out.println("The Contract Employee information is as follows:"+"\n"+"Employee No.:"
		+this.getEmpno()+"Employee No.:"+this.getEmpno()+"\n"
		+"Employee Name.:"+this.getEmpno()+"\n"
		+"Employee Designation:"+this.getDesignation()+"\n"
		+"Employee DateOfbirth:"+this.getDob()+"\n"
		+"Employee JoiningDate:"+this.getJoiningDate()+"\n"
		+"Employee email:"+this.getEmail()+"\n"
		+"Employee startDate"+this.getStartDate()+"\n"
		+"Employee endDate"+this.getEndDate()+"\n"
		+"Employee Organisation"+this.getOrganisation()+"\n"
		+"Employee Address:" + this.Address.Houseno + "," + this.Address.Street + "," + this.Address.Area + "," + this.Address.City + "," + this.Address.State + "\n");
	}
	public Period showDuration(){
		Period p= Period.between(this.getEndDate() , this.getJoiningDate());
		return p;
	}
	


	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public String getOrganisation() {
		return organisation;
	}

	public void setOrganisation(String organisation) {
		this.organisation = organisation;
	}

}
