package Assignment3;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;




public class EmployeeFactory  {

	public static void main(String[] args) throws CloneNotSupportedException {
		// TODO Auto-generated method stub

		Address gad1 = new Address(12, "Comakeit","Madhapur","Hyderabad","Telangana");
		//Address cad1 = new Address(12, "Comakeit","Madhapur","Hyderabad","Telangana");
		//Address aad1 = new Address(12, "Comakeit","Madhapur","Hyderabad","Telangana");
		
		EmployeeFactory.createEmployee(1, 5, "sai" , "trainer" , "1992-05-10", "2018-04-10", "sai92sk@gmail.com",gad1);
		//EmployeeFactory.createEmployee(2, 6, "krishna" , "Trainer" , "1992-02-10", "2018-01-01", "sai92sk@live.com", "2018-01-15", "2018-12-12", "Comakeit", cad1);
		//EmployeeFactory.createEmployee(3, 7, "saikrishna" , "Employee" , "1992-02-10", "2018-06-05", "sai92sk@gmail.com", "2018-06-20", "2018-12-25", "Sir", aad1);
		
		
	}
	
	public static Address changeAddress(Address a1, Address a2)
	{
		a1=a2;
	return a1;
		}
	

	public static EmpMeth createEmployee(int empType,int empno, String name, String designation, String dob, String joiningDate, String email,
			String startDate, String endDate, String changvar, Address Address) throws CloneNotSupportedException{
		
		LocalDate startDate1 = LocalDate.parse(startDate);
		LocalDate endDate1 = LocalDate.parse(endDate);
		EmpAbs g1=null;
		Apprentice a1=null;
		ContractEmployee c1 =null;
		g1=(EmpAbs) createEmployee(empType, empno, name, designation, dob, joiningDate, email, Address);
		
		if(empType == 2)
		{
			c1=new ContractEmployee(g1, startDate1, endDate1, changvar);
			c1.showData();
			System.out.println("The Age of the Employee is:" + c1.getAge());
			System.out.println("No. of months, since employee joined:" + c1.getNumberOfMonths() );
			Period condu = c1.showDuration();
			System.out.println("The Duration of employee is"+ condu.getYears() + "years" + condu.getMonths() + "Months" + condu.getDays() + "Days" + "\n");
			return c1;
		}
		
		if(empType==3)
		{
		a1=new Apprentice(g1, startDate1, endDate1, changvar);
		a1.showData();
		System.out.println("The Age of the Employee is:" + a1.getAge());
		System.out.println("No. of months, since employee joined:" + a1.getNumberOfMonths() );
		Period appdu = a1.showDuration();
		System.out.println("The Duration of employee is"+ appdu.getYears() + "years" + appdu.getMonths() + "Months" + appdu.getDays() + "Days" + "\n");
		return a1;
		}
		return null;
						
		
	}
	
 

	
	public static EmpMeth createEmployee(int empType, int empno, String name, String designation, String dob, String joiningDate, String email, Address Address) throws CloneNotSupportedException{
		
		LocalDate dob1 = LocalDate.parse(dob);
		LocalDate joiningDate1 = LocalDate.parse(joiningDate);
		
		
		EmpAbs g1=new GeneralEmployee(empno,name,designation,dob1,joiningDate1,email,Address);
		EmpAbs ncg=new GeneralEmployee(empno,name,designation,dob1,joiningDate1,email,Address);
	    EmpAbs cg2 ;
	    
	  //changing address
		Address ad2 = new Address(12, "NRT Center","chpet","Guntur","Andhra Pradesh");
		
		List <GeneralEmployee> l1 = new ArrayList <GeneralEmployee>();
		
		if(empType == 1)
		{
		g1.showData();
		ncg = g1;
		l1.add((GeneralEmployee) g1);
		l1.add((GeneralEmployee) ncg);
		
		
		try {
			cg2 = (GeneralEmployee) g1.clone();
			//cg2.showData();
			l1.add((GeneralEmployee) cg2);
			
		
		
		
		     System.out.println("Before Changing Address:");
		     for(EmpAbs pa:l1)
		    	 {
			       System.out.println(pa.empno+" "+pa.name+" "+pa.designation+" "+pa.dob+" "+ pa.joiningDate + " " + pa.Email + " " + pa.Address.Houseno +
					" " + pa.Address.Street + " " + pa.Address.Area + " " + pa.Address.City + " " + pa.Address.State + "\n");
		          }
		
		
		     //calling change address method
		     g1.Address = changeAddress(g1.Address,ad2);
		    
		     System.out.println("After Changing Address:");
		
		
		     for(EmpAbs pa:l1)
		     {
			   System.out.println(pa.empno+" "+pa.name+" "+pa.designation+" "+pa.dob+" "+ pa.joiningDate + " " + pa.Email + " " + pa.Address.Houseno +
					" " + pa.Address.Street + " " + pa.Address.Area + " " + pa.Address.City + " " + pa.Address.State + "\n");
		      }
		      //System.out.println("The Age of the Employee is:" + g1.getAge());
		      //System.out.println("No. of months, since employee joined:" + g1.getNumberOfMonths() + "\n");
		     }
		catch (CloneNotSupportedException ex) {
			System.out.println(ex);
        }
	
		}
		return g1;
		
		
		
	}


}
