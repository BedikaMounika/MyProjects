package Assignment3;
public interface EmpMeth {

	public void showData();
	public int getAge();
	public int getNumberOfMonths();
	public Object clone() throws CloneNotSupportedException;
}
