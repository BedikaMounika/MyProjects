package Assignment2;
public interface EmpMeth {

	public void showData();
	public int getAge();
	public int getNumberOfMonths();
}
