package Assignment2;
import java.time.LocalDate;
import java.time.Period;

public class EmployeeFactory {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EmployeeFactory.createEmployee(1, 5, "sai" , "trainer" , "1992-05-10", "2018-04-10", "sai92sk@gmail.com");
		EmployeeFactory.createEmployee(2, 6, "krishna" , "Trainer" , "1992-02-10", "2018-01-01", "sai92sk@live.com", "2018-01-15", "2018-12-12", "Comakeit");
		EmployeeFactory.createEmployee(3, 7, "saikrishna" , "Employee" , "1992-02-10", "2018-06-05", "sai92sk@gmail.com", "2018-06-20", "2018-12-25", "Sir");
	}

	
	public static EmpMeth createEmployee(int empType,int empno, String name, String designation, String dob, String joiningDate, String email,
			String startDate, String endDate, String changvar){
		
		LocalDate startDate1 = LocalDate.parse(startDate);
		LocalDate endDate1 = LocalDate.parse(endDate);
		Empabs g1=null;
		Apprentice a1=null;
		ContractEmployee c1 =null;
		g1=(Empabs) createEmployee(empType, empno, name, designation, dob, joiningDate, email);
		
		if(empType == 2)
		{
			c1=new ContractEmployee(g1, startDate1, endDate1, changvar);
			c1.showData();
			System.out.println("The Age of the Employee is:" + c1.getAge());
			System.out.println("No. of months, since employee joined:" + c1.getNumberOfMonths() );
			Period appdu = c1.showDuration();
			System.out.println("The Duration of employee is"+ appdu.getYears() + "years" + appdu.getMonths() + "Months" + appdu.getDays() + "Days" + "\n");
		}
		
		if(empType==3)
		{
		a1=new Apprentice(g1, startDate1, endDate1, changvar);
		a1.showData();
		System.out.println("The Age of the Employee is:" + a1.getAge());
		System.out.println("No. of months, since employee joined:" + a1.getNumberOfMonths() );
		Period appdu = a1.showDuration();
		System.out.println("The Duration of employee is"+ appdu.getYears() + "years" + appdu.getMonths() + "Months" + appdu.getDays() + "Days" + "\n");
	    }
						
		return g1;
	}
	

	
	public static EmpMeth createEmployee(int empType, int empno, String name, String designation, String dob, String joiningDate, String email){
		
		LocalDate dob1 = LocalDate.parse(dob);
		LocalDate joiningDate1 = LocalDate.parse(joiningDate);
		
		
		Empabs g1=new GeneralEmployee(empno,name,designation,dob1,joiningDate1,email);
		
		if(empType == 1)
		{
		g1.showData();
		System.out.println("The Age of the Employee is:" + g1.getAge());
		System.out.println("No. of months, since employee joined:" + g1.getNumberOfMonths() + "\n");
		}
		return g1;
		
		
		
	}

}
