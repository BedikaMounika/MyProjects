package Assignment2;
import java.time.LocalDate;
import java.time.Period;

public class Apprentice extends Empabs{
	
	public LocalDate startDate;
	public LocalDate endDate;
	public String reportingTo;

	public Apprentice(int empno, String name, String designation, LocalDate dob, LocalDate joiningDate, String email, LocalDate startDate, LocalDate endDate, String reportingTo) {
		super(empno, name, designation, dob, joiningDate, email);
		// TODO Auto-generated constructor stub
		this.startDate = startDate;
		this.endDate = endDate;
		this.reportingTo = reportingTo;
		
	}
	
	public Apprentice(Empabs Remp, LocalDate startDate, LocalDate endDate,String reportingTo)
	  {
		super(Remp.empno, Remp.name,Remp.designation,Remp.dob,Remp.joiningDate,Remp.Email);
		this.startDate = startDate;
		this.endDate = endDate;
		this.reportingTo = reportingTo;

	}

	
public String toString(){
		
		return this.getEmpno()+"_"+this.getStartDate()+"_"+this.getEndDate()+ "_"+this.getReportingTo();	
		
	}
public void showData(){
	System.out.println("The Apprentice Employee information is as follows:"+"\n"+
	"Employee No.:"+this.getEmpno() + "\n"
	+"Employee Name.:"+this.getName()+"\n"
	+"Employee Designation:"+this.getDesignation()+"\n"
	+"Employee DateOfbirth:"+this.getDob()+"\n"
	+"Employee JoiningDate:"+this.getJoiningDate()+"\n"
	+"Employee email:"+this.getEmail()+"\n"
	+"Employee startDate:"+this.getStartDate()+"\n"
	+"Employee reportingTo:"+this.getReportingTo() + "\n");
}



public Period showDuration(){
	Period p= Period.between(this.getEndDate(), this.getJoiningDate());
	return p;
	}

public LocalDate getStartDate() {
	return startDate;
}

public void setStartDate(LocalDate startDate) {
	this.startDate = startDate;
}

public LocalDate getEndDate() {
	return endDate;
}

public void setEndDate(LocalDate endDate) {
	this.endDate = endDate;
}

public String getReportingTo() {
	return reportingTo;
}

public void setReportingTo(String reportingTo) {
	this.reportingTo = reportingTo;
}



}
