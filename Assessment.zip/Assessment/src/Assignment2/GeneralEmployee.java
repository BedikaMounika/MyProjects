package Assignment2;
import java.time.LocalDate;

public class GeneralEmployee extends Empabs {

	public GeneralEmployee(int empno, String name, String designation, LocalDate dob, LocalDate joiningDate, String email) {
		super(empno, name, designation, dob, joiningDate, email);
		// TODO Auto-generated constructor stub
	}

public String toString(){
		
		return this.getEmpno()+"_"+this.getDesignation();	
		
	}
	
	public void showData(){
		System.out.println("The General Employee information is as follows:"+"\n"+"Employee No.:"
		+this.getEmpno()+"Employee No.:"+this.getEmpno()+"\n"
		+"Employee Name.:"+this.getName()+"\n"
		+"Employee Designation:"+this.getDesignation()+"\n"
		+"Employee DateOfbirth:"+this.getDob()+"\n"
		+"Employee JoiningDate:"+this.getJoiningDate()+"\n"
		+"Employee email:"+this.getEmail() + "\n");
	}
	
}
