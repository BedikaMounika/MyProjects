package Assignment1;
public class GeneralEmployee extends Employee {


	public GeneralEmployee(int empno, String name, String designation, String dobs, String sjoiningDate, String email) {
		super(empno, name, designation, dobs, sjoiningDate, email);
		// TODO Auto-generated constructor stub
	}

	public String toString(){
		
		return this.getEmpno()+"_"+this.getDesignation();	
		
	}
	
	public void showData(){
		System.out.println("Please find below the details of the employee:"+"\n"+"Employee No.:"
		+this.getEmpno()+ "\n"
		+"Employee Name.:"+this.getName()+"\n"
		+"Employee Designation:"+this.getDesignation()+"\n"
		+"Employee DateOfbirth:"+this.getDob()+"\n"
		+"Employee JoiningDate:"+this.getJoiningDate()+"\n"
		+"Employee email:"+this.getEmail() + "\n");
	}
}
