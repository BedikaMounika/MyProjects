package Assignment1;
import java.time.Period;

public class Firstipa {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		GeneralEmployee g1 = new GeneralEmployee(5, "sai", "Trainee", "1992-05-10", "2018-04-05", "sai92sk@gmail.com");
		ContractEmloyee c1 = new ContractEmloyee(6, "krish", "Trainer", "1992-02-10", "2018-01-01", "sai92sk@live.com", "2018-01-15", "2018-12-12", "ComakeIt");
		Apprentice a1 = new Apprentice(7, "SAIKRISHNA", "Employee", "1992-02-10", "2018-06-05", "sai92sk@gmail.com", "2018-06-20", "2018-12-25", "sir");
		
		System.out.println("The General Emp object String representation is:" +  g1.toString());
		System.out.println("The information of General Employee is:");
		g1.showData();
		System.out.println("The age of Employee is:"+ g1.getAge());
		System.out.println("No. of months, since employee joined:" + g1.getNumberOfMonths() + "\n");
		
		
		System.out.println("The Contract Emp object String representation is:" +  c1.toString());
		System.out.println("The information of Contract Employee is:");
		c1.showData();
		System.out.println("The age of Employee is:"+ c1.getAge());
		System.out.println("No. of months, since employee joined:" + c1.getNumberOfMonths() );
		Period condu = c1.showDuration();
		System.out.println("The Duration of employee is"+ condu.getYears() + "years" + condu.getMonths() + "Months" + condu.getDays() + "Days" + "\n");
		
		System.out.println("The Apprentice Emp object String representation is:" +  a1.toString());
		System.out.println("The information of Apprentice Employee is:");
		a1.showData();
		System.out.println("The age of Employee is:"+ a1.getAge());
		System.out.println("No. of months, since employee joined:" + a1.getNumberOfMonths());
		Period appdu = a1.showDuration();
		System.out.println("The Duration of employee is"+ appdu.getYears() + "years" + appdu.getMonths() + "Months" + appdu.getDays() + "Days" );
		
		
	}

}
