package Assignment1;
import java.time.LocalDate;
import java.time.Period;

public class Apprentice extends Employee{
	

	

	public LocalDate startDate;
	public LocalDate endDate;
	public String reportingTo;
	

	public Apprentice(int empno, String name, String designation, String dobs, String sjoiningDate, String email, String sstartdate, String senddate, String reportingTo) {
		super(empno, name, designation, dobs, sjoiningDate, email);
		// TODO Auto-generated constructor stub
		
		this.startDate = LocalDate.parse(sstartdate);
		this.endDate = LocalDate.parse(senddate);
		this.reportingTo = reportingTo;
	}
	
	
public String toString(){
		
		return this.getEmpno()+"_"+this.getStartDate()+"_"+this.getEndDate()+ "_"+this.getReportingTo();	
		
	}
public void showData(){
	System.out.println("Please find below the details of the employee:"+"\n"+
	"Employee No.:"+this.getEmpno()
	+"Employee Name.:"+this.getName()+"\n"
	+"Employee Designation:"+this.getDesignation()+"\n"
	+"Employee DateOfbirth:"+this.getDob()+"\n"
	+"Employee JoiningDate:"+this.getJoiningDate()+"\n"
	+"Employee email:"+this.getEmail()+"\n"
	+"Employee startDate:"+this.getStartDate()+"\n"
	+"Employee reportingTo:"+this.getReportingTo() + "\n");
}



public Period showDuration(){
	Period p= Period.between(this.getEndDate(), this.getJoiningDate());
	return p;
	}

public LocalDate getStartDate() {
	return startDate;
}

public void setStartDate(LocalDate startDate) {
	this.startDate = startDate;
}

public LocalDate getEndDate() {
	return endDate;
}

public void setEndDate(LocalDate endDate) {
	this.endDate = endDate;
}

public String getReportingTo() {
	return reportingTo;
}

public void setReportingTo(String reportingTo) {
	this.reportingTo = reportingTo;
}


}
