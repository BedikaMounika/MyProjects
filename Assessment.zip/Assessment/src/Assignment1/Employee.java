package Assignment1;
import java.time.LocalDate;
import java.time.Period;

public class Employee {

	public int empno;
	public String name;
	public String designation;
	public LocalDate dob;
	public LocalDate joiningDate;
	public String Email;
	
	
	public Employee(int empno, String name, String designation, String dobs, String sjoiningDate, String email) {
		super();
		this.empno = empno;
		this.name = name;
		this.designation = designation;
		this.dob = LocalDate.parse(dobs);
		this.joiningDate = LocalDate.parse(sjoiningDate);
		Email = email;
	}
	
	public int getAge(){
		
		LocalDate curDate = LocalDate.now();	       
	    Period p= Period.between(dob, curDate);
		return p.getYears();
	}
	
	public int getNumberOfMonths(){
		
		LocalDate curDate = LocalDate.now();	       
	    Period p= Period.between(joiningDate, curDate);
		return  ((p.getYears() * 12) + p.getMonths());
	}
	
	public void showData(){
		
	}

	public int getEmpno() {
		return empno;
	}


	public void setEmpno(int empno) {
		this.empno = empno;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getDesignation() {
		return designation;
	}


	public void setDesignation(String designation) {
		this.designation = designation;
	}


	public LocalDate getDob() {
		return dob;
	}


	public void setDob(LocalDate dob) {
		this.dob = dob;
	}


	public LocalDate getJoiningDate() {
		return joiningDate;
	}


	public void setJoiningDate(LocalDate joiningDate) {
		this.joiningDate = joiningDate;
	}


	public String getEmail() {
		return Email;
	}


	public void setEmail(String email) {
		Email = email;
	}

}
