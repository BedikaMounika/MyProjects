package Assignment4;
public class Address {

	int Houseno;
	String Street, Area , City , State;
	
	public Address(int Houseno, String Street, String Area, String City, String State)
	{
		this.Houseno = Houseno;
		this.Street = Street;
		this.Area = Area;
		this.City = City;
		this.State = State;
		
	}
}
