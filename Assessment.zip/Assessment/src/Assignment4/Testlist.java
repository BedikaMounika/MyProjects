package Assignment4;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;


public class Testlist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<Employee> al1  = new ArrayList<Employee>();

		Address gad1 = new Address(12, "Comakeit","Madhapur","Hyderabad","Telangana");
		LocalDate dob1 = LocalDate.parse("1992-02-10");
		LocalDate joiningDate1 = LocalDate.parse( "2018-01-01");
		LocalDate startDate1 = LocalDate.parse("2018-01-15");
		LocalDate endDate1 = LocalDate.parse("2018-12-12");

		
		GeneralEmployee g2 = new GeneralEmployee(1,5,"gkrishna" , "Trainer" ,dob1, joiningDate1, "sai92sk@live.com",gad1);
		al1.add( g2);
		ContractEmployee c2 = new ContractEmployee(2, 6, "krishna" , "Trainer" , dob1, joiningDate1, "sai92sk@live.com", startDate1, endDate1, "Comakeit",gad1);
		al1.add(c2);
		
		Enumeration<Employee> eh = Collections.enumeration(al1); 
		while(eh.hasMoreElements())
		{
			Employee pe = eh.nextElement();
            System.out.println("Value of is: "+ pe.getEmpno() + "\n" + pe.getName() + "\n" );
            
            System.out.println("Employee No.:"
            		+pe.getEmpno()+"\n"
            		+"Employee Name.:"+pe.getName()+"\n"
            		+"Employee Designation:"+pe.getDesignation()+"\n"
            		+"Employee DateOfbirth:"+pe.getDob()+"\n"
            		+"Employee JoiningDate:"+pe.getJoiningDate()+"\n"
            		+"Employee email:"+pe.getEmail() + "\n"
            		+"Employee Address:" + pe.Address.Houseno + "," + pe.Address.Street + "," + pe.Address.Area + "," + pe.Address.City + "," + pe.Address.State + "\n"); 
		}
		
		Iterator<Employee> itr = al1.iterator();
		
		while(itr.hasNext())
		{
			Employee rel = itr.next();
			System.out.println("Employee No.:"
            		+rel.getEmpno()+"\n"
            		+"Employee Name.:"+rel.getName()+"\n"
            		+"Employee Designation:"+rel.getDesignation()+"\n"
            		+"Employee DateOfbirth:"+rel.getDob()+"\n"
            		+"Employee JoiningDate:"+rel.getJoiningDate()+"\n"
            		+"Employee email:"+rel.getEmail() + "\n"
            		+"Employee Address:" + rel.Address.Houseno + "," + rel.Address.Street + "," + rel.Address.Area + "," + rel.Address.City + "," + rel.Address.State + "\n");
			
			}
		
		Iterator<Employee> itr1 = al1.iterator();
		
		while(itr1.hasNext())
		{
	      Employee gete = itr1.next();
	      if(gete.empno == 5)
	      {
	    	  System.out.println("Fing Emp");
	    	  System.out.println("Employee No.:"
	            		+gete.getEmpno()+"\n"
	            		+"Employee Name.:"+gete.getName()+"\n"
	            		+"Employee Designation:"+gete.getDesignation()+"\n"
	            		+"Employee DateOfbirth:"+gete.getDob()+"\n"
	            		+"Employee JoiningDate:"+gete.getJoiningDate()+"\n"
	            		+"Employee email:"+gete.getEmail() + "\n"
	            		+"Employee Address:" + gete.Address.Houseno + "," + gete.Address.Street + "," + gete.Address.Area + "," + gete.Address.City + "," + gete.Address.State + "\n");
	      }
		}
	}

}
