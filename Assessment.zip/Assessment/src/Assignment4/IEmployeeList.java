package Assignment4;
import java.util.Enumeration;
import java.util.Iterator;

public interface IEmployeeList {
	
	public Enumeration<Employee> getEmployee();
	public Iterator<Employee> getEmployeeListIterator();
	public Employee getEmployee(int empno);
	public void addEmployee(Employee Employee);
	
}
