package Assignment4;
import java.time.LocalDate;



public class ContractEmployee extends Employee {

	public LocalDate startDate;
	public LocalDate endDate;
	public String organisation;

	public ContractEmployee(int emptype,int empno, String name, String designation, LocalDate dob, LocalDate joiningDate,
			String email, LocalDate startDate, LocalDate endDate, String organisation , Address Address) {
		super(emptype,empno, name, designation, dob, joiningDate, email,Address);
		// TODO Auto-generated constructor stub
		
		this.startDate = startDate;
		this.endDate = endDate;
		this.organisation = organisation;
	}
	
	

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public String getOrganisation() {
		return organisation;
	}

	public void setOrganisation(String organisation) {
		this.organisation = organisation;
	}

}
