package Assignment4;
import java.time.LocalDate;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.NoSuchElementException;



public class EmployeeListFactory  {

	EmployeeList el = new EmployeeList();
	EmployeeHashList hl = new EmployeeHashList();
	
public void callEnumeration(String listtype)
{
   if(listtype == "LIST")
   {
	   Enumeration<Employee> printenum = el.getEmployee();
	   
	   while(printenum.hasMoreElements())
	   {
	   Employee employee = printenum.nextElement();
		
	   System.out.println("Employee details Stored in List:");
	   printFunction(employee);
	   
	   
	   }
   }
   else if(listtype == "HASH")
   {
	   Enumeration<Employee> printhashenum = hl.getEmployee();
	   while(printhashenum.hasMoreElements())
		{
		   Employee employee = printhashenum.nextElement();
		   System.out.println("Employee details Stored in Hash:");
		   printFunction(employee);
		  
		}
   }
}

public void callIterator(String listtype)
{
	if(listtype == "LIST")
	{
		Iterator<Employee> printiter = el.getEmployeeListIterator();
		   while(printiter.hasNext())
			{
				Employee employee = printiter.next();
				 				   
				 System.out.println("Employee details Stored in List:");
				   printFunction(employee);
				
				}
	}
	   else if(listtype == "HASH")
	   {
		   Iterator<Employee> printhashiter = hl.getEmployeeListIterator();
		   
		   while(printhashiter.hasNext())
			{
				 Employee employee = printhashiter.next();
				   
				 System.out.println("Employee details Stored in Hash:");
				   printFunction(employee);
			}
	   }
}

public void findEmployee(String listtype,int empno)
{
	if(listtype == "LIST")
	{
		   Employee findemp = el.getEmployee(empno);
		   System.out.println("Employee details found in List:");
		   printFunction(findemp);
		  
	}
	   else if(listtype == "HASH")
	   {
		   Employee findemphash = hl.getEmployee(empno);
		   System.out.println("Employee details found in Hash:");
		   printFunction(findemphash);
	   }
}

public void printFunction(Employee employee)
{
	 	   
	   if(employee instanceof GeneralEmployee)
	   {
		   	GeneralEmployee g1 = (GeneralEmployee) employee;
		   	System.out.println("Printing General Employee details:");
			   System.out.println("Employee No.:"
         		+g1.getEmpno()+"\n"
         		+"Employee Name.:"+g1.getName()+"\n"
         		+"Employee Designation:"+g1.getDesignation()+"\n"
         		+"Employee DateOfbirth:"+g1.getDob()+"\n"
         		+"Employee JoiningDate:"+g1.getJoiningDate()+"\n"
         		+"Employee email:"+g1.Email + "\n"
         		+"Employee Address:" + g1.Address.Houseno + "," + g1.Address.Street + "," + g1.Address.Area + "," + g1.Address.City + "," + g1.Address.State + "\n");
     		
	   }
	  
	   else if (employee instanceof ContractEmployee)
	   {
		 
			   ContractEmployee c3 = (ContractEmployee) employee;
			   System.out.println("Prining Contract Employee details:");
			   
			   System.out.println("Employee No.:"
		           		+c3.getEmpno()+"\n"
		           		+"Employee Name.:"+c3.getName()+"\n"
		           		+"Employee Designation:"+c3.getDesignation()+"\n"
		           		+"Employee DateOfbirth:"+c3.dob+"\n"
		           		+"Employee JoiningDate:"+c3.getJoiningDate()+"\n"
		           		+"Employee email:"+c3.getEmail()+ "\n"
		           		+"Employee startDate:"+c3.getStartDate()+ "\n"
		           		+"Employee endDate:"+c3.getEndDate()+ "\n"
		           		+"Employee organisation:"+c3.getOrganisation()+ "\n"
		           		+"Employee Address:" + c3.Address.Houseno + "," + c3.Address.Street + "," + c3.Address.Area + "," + c3.Address.City + "," + c3.Address.State + "\n");
	       		
		  }
	   else if (employee instanceof Apprentice)
	   {
		   
				Apprentice ap = (Apprentice) employee;
				System.out.println("Printing Apprentice Employee details:");
	           System.out.println("Employee No.:"
	           		+ap.getEmpno()+"\n"
	           		+"Employee Name.:"+ap.getName()+"\n"
	           		+"Employee Designation:"+ap.getDesignation()+"\n"
	           		+"Employee DateOfbirth:"+ap.getDob()+"\n"
	           		+"Employee JoiningDate:"+ap.getJoiningDate()+"\n"
	           		+"Employee email:"+ap.Email + "\n"
	           		+"Employee startDate:"+ap.getStartDate() + "\n"
	           		+"Employee endDate:"+ap.getEndDate() + "\n"
	           		+"Employee ReportingTo:"+ap.getReportingTo() + "\n"
	           		+"Employee Address:" + ap.Address.Houseno + "," + ap.Address.Street + "," + ap.Address.Area + "," + ap.Address.City + "," + ap.Address.State + "\n");
	       		
	   }
}
	
	public void createList(String listtype,int emptype,int empno, String name, String designation, String dob, String joiningDate, String email,  Address Address)
	{
		LocalDate dob1 = LocalDate.parse(dob);
		LocalDate joiningDate1 = LocalDate.parse(joiningDate);
		
		if(listtype == "LIST")
		   {
		   	if(emptype == 1)
		   	createEmployee(el,emptype, empno, name, designation, dob1, joiningDate1, email, Address);
		   	
	        }
	   else if(listtype == "HASH")
		   {
		   if(emptype == 1)
		   	createEmployee(hl,emptype, empno, name, designation, dob1, joiningDate1, email, Address);
		   	
		   }
	

	}
	
	
public void createList(String listtype,int emptype,int empno, String name, String designation, String dob, String joiningDate, String email,
		String startDate, String endDate, String changvar, Address Address) throws NoSuchElementException
{
	LocalDate dob1 = LocalDate.parse(dob);
	LocalDate joiningDate1 = LocalDate.parse(joiningDate);
	LocalDate startDate1 = LocalDate.parse(startDate);
	LocalDate endDate1 = LocalDate.parse(endDate);


	
   if(listtype == "LIST")
	   {
	   	   
	   	if(emptype == 2 || emptype == 3)
	   	createEmployee(el,emptype,empno,name, designation, dob1, joiningDate1, email, startDate1, endDate1, changvar, Address);
        }
   else if(listtype == "HASH")
	   {
	   	if(emptype == 2 || emptype == 3)
	   		createEmployee(hl,emptype,empno,name, designation, dob1, joiningDate1, email, startDate1, endDate1, changvar, Address);
	   }
}


//list type add employee methods
public static IEmployeeList createEmployee(EmployeeList el, int emptype, int empno, String name, String designation, LocalDate dob, LocalDate joiningDate, String email, Address Address)
{
	if(emptype == 1)
	{
		GeneralEmployee g1=new GeneralEmployee(emptype,empno,name,designation,dob,joiningDate,email,Address);
        el.addEmployee(g1);
        
    }
return null;
}

public static IEmployeeList createEmployee(EmployeeList el, int emptype,int empno, String name, String designation, LocalDate dob, LocalDate joiningDate, String email,
		LocalDate startDate, LocalDate endDate, String changvar, Address Address) 
{
	if(emptype == 2)
		{
		ContractEmployee c1=new ContractEmployee(emptype, empno, name, designation, dob, joiningDate, email, startDate, endDate, changvar, Address);
        el.addEmployee(c1);
        }
     else if (emptype == 3)
    	 {
    	 Apprentice a1=new Apprentice(emptype, empno, name, designation, dob, joiningDate, email, startDate, endDate, changvar, Address);
         el.addEmployee(a1);
         }

return null;
}


//Hash type add employee methods

public static IEmployeeList createEmployee(EmployeeHashList hl, int emptype, int empno, String name, String designation, 
		LocalDate dob, LocalDate joiningDate, String email, Address Address)
{
	if(emptype == 1)
		{
		GeneralEmployee g1=new GeneralEmployee(emptype,empno,name,designation,dob,joiningDate,email,Address);
        hl.addEmployee(g1);
        
        }
return null;
}

public static IEmployeeList createEmployee(EmployeeHashList hl, int emptype,int empno, String name, String designation, LocalDate dob, LocalDate joiningDate, String email,
		LocalDate startDate, LocalDate endDate, String changvar, Address Address)
{
	if(emptype == 2)
		{
		ContractEmployee c1=new ContractEmployee(emptype, empno, name, designation, dob, joiningDate, email, startDate, endDate, changvar, Address);
        hl.addEmployee(c1);
         }
     else if (emptype == 3)
    	 {
    	 Apprentice a1=new Apprentice(emptype, empno, name, designation, dob, joiningDate, email, startDate, endDate, changvar, Address);
         hl.addEmployee(a1);
         }
return null;
}


}
