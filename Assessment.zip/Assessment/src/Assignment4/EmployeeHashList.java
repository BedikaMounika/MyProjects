package Assignment4;
import java.util.Collection;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;


public class EmployeeHashList implements IEmployeeList {

	Hashtable<Integer, Employee> h1 = new Hashtable<Integer, Employee>();
	
	@Override
	public Enumeration<Employee> getEmployee() {
		// TODO Auto-generated method stub
		Enumeration<Employee> eh = h1.elements();
		return eh;
	}

	@Override
	public Iterator<Employee> getEmployeeListIterator() {
		// TODO Auto-generated method stub
		
		Collection<Employee> entrySet = h1.values();

		Iterator<Employee> itr = entrySet.iterator();
	
		return (Iterator<Employee>) itr;
	
		
	}

	@Override
	public Employee getEmployee(int empno) {
		
		Employee pe = h1.get(empno);
		return pe;
		
		    }

	@Override
	public void addEmployee(Employee Employee) {
		// TODO Auto-generated method stub
		h1.put(Employee.empno, Employee);
	}

}
