package Assignment4;
import java.time.LocalDate;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class Testhash {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		Hashtable<Integer, Employee> h1 = new Hashtable<Integer, Employee>();

		Address gad1 = new Address(12, "Comakeit","Madhapur","Hyderabad","Telangana");
		LocalDate dob1 = LocalDate.parse("1992-02-10");
		LocalDate joiningDate1 = LocalDate.parse( "2018-01-01");
		LocalDate startDate1 = LocalDate.parse("2018-01-15");
		LocalDate endDate1 = LocalDate.parse("2018-12-12");

		
		GeneralEmployee g2 = new GeneralEmployee(1,5,"gkrishna" , "Trainer" ,dob1, joiningDate1, "sai92sk@live.com",gad1);
		h1.put(1, g2);
		ContractEmployee c2 = new ContractEmployee(2, 6, "krishna" , "Trainer" , dob1, joiningDate1, "sai92sk@live.com", startDate1, endDate1, "Comakeit",gad1);
		h1.put(2,c2);
		
		Enumeration<Employee> eh = h1.elements();
		while(eh.hasMoreElements())
		{
			Employee pe3 = eh.nextElement();
			System.out.println("Employee No.:"
            		+pe3.empno+"\n"
            		+"Employee Name.:"+pe3.getName()+"\n"
            		+"Employee Designation:"+pe3.getDesignation()+"\n"
            		+"Employee DateOfbirth:"+pe3.getDob()+"\n"
            		+"Employee JoiningDate:"+pe3.getJoiningDate()+"\n"
            		+"Employee email:"+pe3.getEmail() + "\n"
            		+"Employee Address:" + pe3.Address.Houseno + "," + pe3.Address.Street + "," + pe3.Address.Area + "," + pe3.Address.City + "," + pe3.Address.State + "\n");
		}
		
		Set<Entry<Integer, Employee>> entrySet = h1.entrySet();

		Iterator<Entry<Integer, Employee>> itr = entrySet.iterator();

		
		while(itr.hasNext())
		{
			Employee pe3 = itr.next().getValue();
			System.out.println("Employee No.:"
            		+pe3.empno+"\n"
            		+"Employee Name.:"+pe3.getName()+"\n"
            		+"Employee Designation:"+pe3.getDesignation()+"\n"
            		+"Employee DateOfbirth:"+pe3.getDob()+"\n"
            		+"Employee JoiningDate:"+pe3.getJoiningDate()+"\n"
            		+"Employee email:"+pe3.getEmail() + "\n"
            		+"Employee Address:" + pe3.Address.Houseno + "," + pe3.Address.Street + "," + pe3.Address.Area + "," + pe3.Address.City + "," + pe3.Address.State + "\n");
		}
					
		
		Employee pe = h1.get(1);
		System.out.println("Employee No.:"
        		+pe.getEmpno()+"\n"
        		+"Employee Name.:"+pe.getName()+"\n"
        		+"Employee Designation:"+pe.getDesignation()+"\n"
        		+"Employee DateOfbirth:"+pe.getDob()+"\n"
        		+"Employee JoiningDate:"+pe.getJoiningDate()+"\n"
        		+"Employee email:"+pe.getEmail() + "\n"
        		+"Employee Address:" + pe.Address.Houseno + "," + pe.Address.Street + "," + pe.Address.Area + "," + pe.Address.City + "," + pe.Address.State + "\n"); 
	}

}
