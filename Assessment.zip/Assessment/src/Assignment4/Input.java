package Assignment4;
public class Input {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		EmployeeListFactory elf = new EmployeeListFactory(); 
		
		
		Address gad1 = new Address(12, "Comakeit","Madhapur","Hyderabad","Telangana");
		
		//2 General Employee in Hash
		elf.createList("HASH",1, 5, "krishna" , "Trainer" , "1992-02-10", "2018-01-01", "sai92sk@live.com",gad1);
		elf.createList("HASH",1, 6, "sai" , "Trainee" , "1992-05-10", "2018-05-01", "sai92sk@gmail.com",gad1);
		
		//2 General Employee in List
		elf.createList("LIST",1, 7, "saikrishna" , "Employee" , "1992-07-10", "2018-06-01", "sai92sk@hotmail.com",gad1);
		elf.createList("LIST",1, 8, "glnkrishna" , "programmer" , "1992-03-10", "2018-06-01", "sai92sk@gmail.com",gad1);
	
		//2 Contract Employees in Hash
		elf.createList("HASH",2, 10, "G L N SAI" , "NEWTrainer" , "1992-02-10", "2018-01-01", "sai92sk@live.com", "2018-01-15", "2018-12-12", "Comakeit",gad1);
		elf.createList("HASH",2, 11, "Chris" , "Developer" , "1992-02-10", "2018-02-01", "sai92sk@live.com", "2018-02-15", "2018-12-25", "Microsoft",gad1);
		
		//2 Contract Employees in LIST
		elf.createList("LIST",2, 12, "Strange" , "Magician" , "1992-01-10", "2018-01-01", "sai92sk@live.com", "2018-01-15", "2018-12-12", "Google",gad1);
		elf.createList("LIST",2, 13, "Robert" , "techie" , "1992-02-10", "2018-02-01", "sai92sk@live.com", "2018-02-15", "2018-12-20", "Apple",gad1);
		
		//3 Apprentice in HASH
		elf.createList("HASH",3, 14, "sai" , "Trainer" , "1992-02-10", "2018-01-01", "sai92sk@live.com", "2018-01-15", "2018-12-12", "SIR",gad1);
		elf.createList("HASH",3, 15, "sai" , "Trainer" , "1992-02-10", "2018-01-01", "sai92sk@live.com", "2018-01-15", "2018-12-12", "MADAM",gad1);
		elf.createList("HASH",3, 16, "sai" , "Trainer" , "1992-02-10", "2018-01-01", "sai92sk@live.com", "2018-01-15", "2018-12-12", "Boss",gad1);
		
		//3 Apprentice in LIST
		elf.createList("LIST",3, 17, "saikrishna" , "Trainer" , "1992-02-10", "2018-01-01", "sai92sk@live.com", "2018-01-15", "2018-12-12", "Sir",gad1);
		elf.createList("LIST",3, 18, "saikrishna" , "Trainer" , "1992-02-10", "2018-01-01", "sai92sk@live.com", "2018-01-15", "2018-12-12", "Madam",gad1);
		elf.createList("LIST",3, 19, "sai" , "Trainer" , "1992-02-10", "2018-01-01", "sai92sk@live.com", "2018-01-15", "2018-12-12", "boss",gad1);
		
		//call list type enum
		//elf.callEnumeration("LIST");
		
		//call Hash type enum
		elf.callEnumeration("HASH");
		
		//call List type iterator
		//elf.callIterator("HASH");
		
		//call List type iterator
	     //elf.callIterator("LIST");
		
	     
	     //elf.findEmployee("HASH", 14);
	     
	     //elf.findEmployee("LIST", 7);
	}

}
