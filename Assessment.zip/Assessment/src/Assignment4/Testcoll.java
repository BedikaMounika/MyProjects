package Assignment4;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;

public class Testcoll {



	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		ArrayList<Employee> al = new ArrayList<Employee>(); 
		
		Address gad1 = new Address(12, "Comakeit","Madhapur","Hyderabad","Telangana");
		
		//2 General Employee in List
		LocalDate dob1 = LocalDate.parse("1992-07-01");
		LocalDate joiningDate1 = LocalDate.parse("2018-06-01");
		LocalDate startDate1 = LocalDate.parse("2018-06-25");
		LocalDate endDate1 = LocalDate.parse("2018-12-12");
		
		GeneralEmployee g1 = new GeneralEmployee(1,7, "saikrishna" , "Employee" , dob1, joiningDate1, "sai92sk@gmail.com",gad1);
		al.add( g1);
		GeneralEmployee g2 = new GeneralEmployee(1, 8, "glnkrishna" , "programmer" , dob1, joiningDate1, "sai92sk@gmail.com",gad1);
	    al.add(g2);
	
	    ContractEmployee c1 =new ContractEmployee(2, 12, "Strange" , "Magician" , dob1, joiningDate1, "sai92sk@live.com", startDate1, endDate1, "Google",gad1);
		al.add(c1);
		ContractEmployee c2 =new ContractEmployee(2, 13, "Robert" , "techie" , dob1, joiningDate1, "sai92sk@live.com", startDate1, endDate1, "Apple",gad1);
		al.add(c2);
		
		Apprentice a1 = new Apprentice(3, 17, "saikrishna" , "Trainer" , dob1, joiningDate1, "sai92sk@live.com", startDate1, endDate1, "Sir",gad1);
		al.add(a1);
	    Apprentice a2 = new Apprentice(3, 18, "saikrishna" , "Trainer" , dob1, joiningDate1, "sai92sk@live.com", startDate1, endDate1, "Madam",gad1);
		al.add(a2);
	    Apprentice a3 = new Apprentice(3, 19, "sai" , "Trainer" , dob1, joiningDate1, "sai92sk@live.com", startDate1, endDate1, "boss",gad1);
		al.add(a3);
		
		
	    Enumeration<Employee> printenum = Collections.enumeration(al); 
			   
			  
			   while(printenum.hasMoreElements())
				{
					Employee pe = printenum.nextElement();
					if(pe instanceof ContractEmployee)
					{
						ContractEmployee c3 = (ContractEmployee) pe;
						System.out.println("Employee No.:"
				           		+c3.getEmpno()+"\n"
				           		+"Employee Name.:"+c3.getName()+"\n"
				           		+"Employee Designation:"+c3.getDesignation()+"\n"
				           		+"Employee DateOfbirth:"+c3.dob+"\n"
				           		+"Employee JoiningDate:"+c3.getJoiningDate()+"\n"
				           		+"Employee email:"+c3.getEmail()+ "\n"
				           		+"Employee startDate:"+c3.getStartDate()+ "\n"
				           		+"Employee endDate:"+c3.getEndDate()+ "\n"
				           		+"Employee organisation:"+c3.getOrganisation()+ "\n"
				           		+"Employee Address:" + pe.Address.Houseno + "," + pe.Address.Street + "," + pe.Address.Area + "," + pe.Address.City + "," + pe.Address.State + "\n");
					}
						
		           System.out.println("Employee No.:"
		           		+pe.getEmpno()+"\n"
		           		+"Employee Name.:"+pe.getName()+"\n"
		           		+"Employee Designation:"+pe.getDesignation()+"\n"
		           		+"Employee DateOfbirth:"+pe.getDob()+"\n"
		           		+"Employee JoiningDate:"+pe.getJoiningDate()+"\n"
		           		+"Employee email:"+pe.Email + "\n"
		           		+"Employee Address:" + pe.Address.Houseno + "," + pe.Address.Street + "," + pe.Address.Area + "," + pe.Address.City + "," + pe.Address.State + "\n");
		       		}
			   }
			  
			   
		   }

	


