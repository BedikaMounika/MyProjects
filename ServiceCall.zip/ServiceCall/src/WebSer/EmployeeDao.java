package WebSer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
public class EmployeeDao 
{
	
	public int DeleteAddress(String empno) throws SQLException
	{
	Connection adcon = ConnectDb.getConnection();
	PreparedStatement stmt = null;
	int val=0;
	int retval=0;
	try
	{
	stmt = adcon.prepareStatement("Delete from address where address.addempno=?");
	stmt.setInt(1,Integer.parseInt(empno));
	val = stmt.executeUpdate();
	if (val > 0)
	retval =1;

	}
	catch(Exception e)
	{
	System.out.println(e);
	}
	finally
	{
	stmt.close();
	adcon.close();
	}
	return retval;
	}

	@SuppressWarnings("finally")
	public int deleteGeneralEmployee(String empno) throws SQLException
	{
	Connection upgencon = ConnectDb.getConnection();
	PreparedStatement stmt = null;
	int val =0;
	int retval =0;
	try
	{ 
	int addvalue = DeleteAddress(empno);
	stmt = upgencon.prepareStatement("delete from generalemployee WHERE generalemployee.empno = ?");
	stmt.setInt(1, Integer.parseInt(empno));
	val = stmt.executeUpdate();
	if (val > 0 && addvalue > 0)
	retval =1;
	System.out.println(val); 
	System.out.println(addvalue);
	}
	catch(Exception e)
	{
	System.out.println(e);
	}
	finally
	{
	stmt.close();

	upgencon.close();
	return retval;	
	}
	}
	public String deleteAddress(String empno) throws SQLException
	 {
		 Connection adcon = ConnectDb.getConnection();
		 PreparedStatement stmt = null;
		 try
			{
				stmt = adcon.prepareStatement("delete from address where addempno = ? ");
			    stmt.setString(1, empno);
			    stmt.executeUpdate();
	            
	         }
	        catch(Exception e)
			{
	        	System.out.println(e);
		     }
		 finally
		 {
			 stmt.close();
			 adcon.close();
		 }
		return empno;
	 }
	
	@SuppressWarnings("finally")
	public String deleteEmployee(String empno) throws SQLException
    {
		
		 Connection adcon = ConnectDb.getConnection();
		Connection gcon = ConnectDb.getConnection();
		ResultSet res = null;
		PreparedStatement stmt = null;
		  try { 
			  stmt=adcon.prepareStatement("delete from address where addempno = ? ");
			  String sql = ("delete from generalemployee where empno = ? "); 
			  stmt = gcon.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			  stmt.setString(1, empno);
			    
				stmt.executeUpdate();
			
			
		    res = stmt.getGeneratedKeys();
			if(res.next())
				empno = res.getString(1);
			deleteAddress(empno);
			 
         }
        catch(Exception e)
		{
        	System.out.println(e);
	     }
		  finally {
			  if(!res.next())
				  res.close();
			  stmt.close();
			  gcon.close();
			  
         return empno;
     
		  }
	 }	 @SuppressWarnings("finally")
	public int deleteContract(String name, String designation, String dob,String joiningDate, String email, String startDate, String endDate, String organisation, Address Address) throws SQLException
	 {
		String empno = saveEmployee(name, designation, dob, joiningDate, email, Address);
		Connection cecon = ConnectDb.getConnection();
		PreparedStatement stmt = null;
		int val = 0;
		try
		{
			stmt = cecon.prepareStatement("delete from contractemployee where empno = ?");
			stmt.setString(1, empno);
			stmt.setObject(2, startDate);
			stmt.setObject(3, endDate);
			stmt.setString(4, organisation);
		    val = stmt.executeUpdate();
           
         }
        catch(Exception e)
		{
        	System.out.println(e);
	     }
		finally
		{
			stmt.close();
			cecon.close();
			return val;
		}
		
	 }
	 @SuppressWarnings("finally")
	public String deleteApprentice(String name, String designation, String dob, String joiningDate, String email, String startDate, String endDate, String reportingTo, Address Address) throws SQLException
	 {
		 String empno = saveEmployee(name, designation, dob, joiningDate, email, Address);
		 Connection apcon = ConnectDb.getConnection();
		 PreparedStatement stmt = null;
		 String val=null;
			try
			{
				stmt = apcon.prepareStatement("delete from apprentice where empno = ?");
				stmt.setString(1, empno);
				stmt.setObject(2, startDate);
				stmt.setObject(3, endDate);
				stmt.setString(4, reportingTo);
				val = "stmt.executeUpdate()";
	            
	         }
	        catch(Exception e)
			{
	        	System.out.println(e);
		     }
			finally
			{
				stmt.close();
				apcon.close();
				return val;
			}
		
	  }
	@SuppressWarnings("finally")
	public String saveEmployee(String name, String designation, String dob, String joiningdate, String email, Address Address) throws SQLException
    {
		
		String empno = null;
		Connection gcon = ConnectDb.getConnection();
		ResultSet res = null;
		PreparedStatement stmt = null;
		  try { 
			  String sql = "insert into generalemployee (empname,designation,dob,joiningdate,email) values (?,?,?,?,?)";
			  stmt = gcon.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
		   
			    stmt.setString(1, name);
				stmt.setString(2, designation);
				stmt.setObject(3, dob);
				stmt.setObject(4, joiningdate);
				stmt.setString(5, email);
				stmt.executeUpdate();
			
			
		    res = stmt.getGeneratedKeys();
			if(res.next())
				empno = res.getString(1);
			addAddress(empno,Address.Houseno,Address.Street,Address.Area,Address.City,Address.State);
			 
         }
        catch(Exception e)
		{
        	System.out.println(e);
	     }
		  finally {
			  if(!res.next())
				  res.close();
			  stmt.close();
			  gcon.close();
			  
         return empno;
     
		  }
	 }
	 @SuppressWarnings("finally")
	public int saveContract(String name, String designation, String dob,String joiningDate, String email, String startDate, String endDate, String organisation, Address Address) throws SQLException
	 {
		String empno = saveEmployee(name, designation, dob, joiningDate, email, Address);
		Connection cecon = ConnectDb.getConnection();
		PreparedStatement stmt = null;
		int val = 0;
		try
		{
			stmt = cecon.prepareStatement("insert into contractemployee (conempno,startdate,enddate,organisation) values (?,?,?,?)");
			stmt.setString(1, empno);
			stmt.setObject(2, startDate);
			stmt.setObject(3, endDate);
			stmt.setString(4, organisation);
		    val = stmt.executeUpdate();
           
         }
        catch(Exception e)
		{
        	System.out.println(e);
	     }
		finally
		{
			stmt.close();
			cecon.close();
			return val;
		}
		
	 }
	 @SuppressWarnings("finally")
	public String saveApprentice(String name, String designation, String dob, String joiningDate, String email, String startDate, String endDate, String reportingTo, Address Address) throws SQLException
	 {
		 String empno = saveEmployee(name, designation, dob, joiningDate, email, Address);
		 Connection apcon = ConnectDb.getConnection();
		 PreparedStatement stmt = null;
		 String val=null;
			try
			{
				stmt = apcon.prepareStatement("insert into apprentice (appempno,startdate,enddate,reportingto) values (?,?,?,?)");
				stmt.setString(1, empno);
				stmt.setObject(2, startDate);
				stmt.setObject(3, endDate);
				stmt.setString(4, reportingTo);
				val = "stmt.executeUpdate()";
	            
	         }
	        catch(Exception e)
			{
	        	System.out.println(e);
		     }
			finally
			{
				stmt.close();
				apcon.close();
				return val;
			}
		
	  }
	 public void addAddress(String empno, String houseno, String street, String area, String city, String state) throws SQLException
	 {
		 Connection adcon = ConnectDb.getConnection();
		 PreparedStatement stmt = null;
		 try
			{
				stmt = adcon.prepareStatement("insert into Address (addempno,houseno,street,area,city,state) values (?,?,?,?,?,?)");
			    stmt.setString(1, empno);
			    stmt.setString(2, houseno);
			    stmt.setString(3, street);
			    stmt.setString(4, area);
			    stmt.setString(5, city);
			    stmt.setString(6, state);
			    stmt.executeUpdate();
	            
	         }
	        catch(Exception e)
			{
	        	System.out.println(e);
		     }
		 finally
		 {
			 stmt.close();
			 adcon.close();
		 }
	 }
	 
	 @SuppressWarnings("finally")
	public Employee findEmployee(String empno, String emptype) throws SQLException
	 {
		 Connection findcon = ConnectDb.getConnection();
		 PreparedStatement stmt = null;
		 PreparedStatement stmt2 = null;
		 PreparedStatement stmt3 = null;
		 Employee emp = null;
		 ResultSet rs = null;
		 ResultSet crs = null;
		 ResultSet ars = null;
		 try
		 {
			 if(emptype == "1")
			 {
				 	
				 stmt = findcon.prepareStatement( "SELECT table1.empno,table1.empname,table1.designation, table1.dob,table1.joiningdate, table1.email, table2.houseno, table2.street, table2.area, table2.city, table2.state FROM \r\n"+
				            "(SELECT generalemployee.empno,generalemployee.empname,generalemployee.designation, generalemployee.dob,generalemployee.joiningdate, generalemployee.email \r\n" + 
				    		"FROM generalemployee\r\n" + 
				    		"WHERE generalemployee.empno NOT IN \r\n" + 
				    		"((SELECT conempno from contractemployee)\r\n" + 
				    		"UNION (SELECT appempno from apprentice))) table1\r\n" +
				    		"LEFT JOIN \r\n"+
				    		"(SELECT * FROM Address ) table2\r\n"+
				    		"ON table1.empno = table2.addempno\r\n"+
				    		"Where table1.empno = ?");
				 stmt.setString(1, empno);
				 rs = stmt.executeQuery();
				 if(rs.next())
				 {
				 Address gad = new Address(rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11));
				 emp = new GeneralEmployee(emptype, rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), gad);
				 }
			 }
			 else if (emptype == "2")
			 {
			  stmt2 = findcon.prepareStatement("SELECT generalemployee.empno,generalemployee.empname,generalemployee.designation, generalemployee.dob,generalemployee.joiningdate, generalemployee.email, contractemployee.startdate,contractemployee.enddate, contractemployee.organisation,"
			    		+ "Address.houseno, Address.street, Address.area, Address.city, Address.state\r\n" + 
			    		"FROM (generalemployee\r\n" + 
			    		"RIGHT JOIN contractemployee \r\n" + 
			    		"ON generalemployee.empno = contractemployee.conempno)\r\n" +
			    		"LEFT JOIN Address\r\n"+
			    		"ON generalemployee.empno = Address.addempno\r\n"+
			    		"WHERE generalemployee.empno = ?");
			  stmt2.setString(1, empno);
			  crs = stmt2.executeQuery();
			  if(crs.next())
			  {
			  Address cad = new Address(crs.getString(10), crs.getString(11), crs.getString(12), crs.getString(13), crs.getString(14));
				emp = new ContractEmployee(emptype, crs.getString(1), crs.getString(2), crs.getString(3), crs.getString(4), crs.getString(5), crs.getString(6), crs.getString(7), crs.getString(8), crs.getString(9), cad);
			  }
			  }
			 else if(emptype == "3")
			 {
				 stmt3 = findcon.prepareStatement("SELECT generalemployee.empno,generalemployee.empname,generalemployee.designation, generalemployee.dob,generalemployee.joiningdate, generalemployee.email, apprentice.startdate,apprentice.enddate, apprentice.reportingto,"
							+ "Address.houseno, Address.street, Address.area, Address.city, Address.state\r\n" + 
				    		"FROM (generalemployee\r\n" + 
				    		"RIGHT JOIN apprentice \r\n" + 
				    		"ON generalemployee.empno = apprentice.appempno)\r\n" +
				    		"LEFT JOIN Address\r\n"+
				    		"ON generalemployee.empno = Address.addempno\r\n"+
				    		"WHERE generalemployee.empno = ?");
				 stmt3.setString(1, empno);
				 ars = stmt3.executeQuery();
				 if(ars.next())
				 {
				 Address aad = new Address(ars.getString(10), ars.getString(11), ars.getString(12), ars.getString(13), ars.getString(14));
				 emp = new Apprentice(emptype, ars.getString(1), ars.getString(2), ars.getString(3), ars.getString(4), ars.getString(5), ars.getString(6), ars.getString(7), ars.getString(8), ars.getString(9), aad);
			 }
			 }
			 
		 }
		 catch(Exception e)
			{
	        	System.out.println(e);
		     }
		 finally
		 {
			 
			 if (emptype == "1")
			 {
				 if(!rs.next())
				 {
				 rs.close();
				 stmt.close();
				 }
			 }
			 else if(emptype == "2")
			 {
				 if(!crs.next())
				 {
				 crs.close();
				 stmt2.close();
				 }
			 }
			 else if(emptype == "3")
			 {
				 if(!ars.next())
				 {
			     ars.close();
			     stmt3.close();
				 }
			 }
			 
			 
			 
			 findcon.close();
			 
			 return emp;
		 }
		
	 }
	 
	 @SuppressWarnings("finally")
	public int updateGeneralEmployee(GeneralEmployee ge) throws SQLException
	 {
		 Connection upgencon = ConnectDb.getConnection();
		 PreparedStatement stmt = null;
		
		 int val =0;
		 int retval =0;
		 try
		 {
			 stmt = upgencon.prepareStatement("update generalemployee set generalemployee.empname = ?,generalemployee.designation = ?, generalemployee.dob = ?,generalemployee.joiningdate = ?, generalemployee.email = ? WHERE generalemployee.empno = ?");
			 stmt.setString(1, ge.getName());
			 stmt.setString(2, ge.getDesignation());
			 stmt.setString(3, ge.getDob());
			 stmt.setString(4, ge.getJoiningDate());
			 stmt.setString(5, ge.getEmail());
			 stmt.setString(6, ge.getEmpno());
			 val = stmt.executeUpdate();
			
			int addvalue = updateAddress(ge.getEmpno(),ge.getAddress());
			 
			 if (val > 0 && addvalue > 0)
				 retval =1;
				 
		 
		 }
		 catch(Exception e)
			{
	        	System.out.println(e);
		     }
		 finally
		 {
			 stmt.close();
			 upgencon.close();
			 return retval;	 
		 }
		
		 
	 }
	 @SuppressWarnings("finally")
	public int updateContractEmployee(ContractEmployee ce) throws SQLException
	 {
		 Connection upcotcon = ConnectDb.getConnection();
		 PreparedStatement stmt = null;
		 GeneralEmployee cge = new GeneralEmployee("1",ce.getEmpno(), ce.getName(), ce.getDesignation(), ce.getDob(), ce.getJoiningDate(), ce.getEmail(), ce.getAddress());
		 int retval = 0;
		 try
		 {
			 
			 int genval = updateGeneralEmployee(cge);
			 stmt = upcotcon.prepareStatement("update contractemployee set contractemployee.startdate = ?,contractemployee.enddate = ?, contractemployee.organisation = ? WHERE contractemployee.conempno = ?");
			 stmt.setString(1, ce.getStartDate());
			 stmt.setString(2, ce.getEndDate());
			 stmt.setString(3, ce.getOrganisation());
			 stmt.setString(4, ce.getEmpno());
			 int conval = stmt.executeUpdate();
			 if (genval > 0 && conval >0)
				 retval =1;
		 }
		 catch(Exception e)
			{
	        	System.out.println(e);
		     }
		 finally
		 {
			 stmt.close();
			 upcotcon.close();
			 return retval; 
		 }
		
		 
	 }
	 @SuppressWarnings("finally")
	public int updateApprenticeEmployee(Apprentice ae) throws SQLException
	 {
		 Connection upapcon = ConnectDb.getConnection();
		 PreparedStatement stmt = null;
		 GeneralEmployee cge = new GeneralEmployee("1",ae.getEmpno(), ae.getName(), ae.getDesignation(), ae.getDob(), ae.getJoiningDate(), ae.getEmail(), ae.getAddress());
		 int retval = 0;
		 try
		 {
			 int genval = updateGeneralEmployee(cge);
			 stmt = upapcon.prepareStatement("update apprentice set apprentice.startdate = ?,apprentice.enddate = ?, apprentice.reportingto = ? WHERE apprentice.appempno = ?");
			
			 stmt.setString(3, ae.getStartDate());
			 stmt.setString(3, ae.getEndDate());
			 stmt.setString(3, ae.getReportingTo());
			 stmt.setString(4, ae.getEmpno());
			 int adval = stmt.executeUpdate();
			 if (genval > 0 && adval >0)
				 retval =1;
		 }
		 catch(Exception e)
			{
	        	System.out.println(e);
		     }
		 finally
		 {
			 stmt.close();
			 upapcon.close();
			 return retval; 
		 }
		
		 
	 }
	 
	 @SuppressWarnings("finally")
	public int updateAddress(String empno, Address ad) throws SQLException
	 {
		 Connection upadcon = ConnectDb.getConnection();
		 PreparedStatement adstmt = null;
		 int adval =0;
		 try
		 {
		 adstmt = upadcon.prepareStatement("UPDATE Address set Address.houseno = ?, Address.street = ?, Address.area = ?, Address.city = ?, Address.state = ? WHERE Address.addempno = ?");
		 adstmt.setString(1, ad.Houseno);
		 adstmt.setString(2, ad.Street);
		 adstmt.setString(3, ad.Area);
		 adstmt.setString(4, ad.City);
		 adstmt.setString(5, ad.State);
		 adstmt.setString(6, empno);
		 adval = adstmt.executeUpdate();
		 }
		 catch(Exception e)
			{
	        	System.out.println(e);
		     }
		 finally
		 {
			 adstmt.close();
			 upadcon.close();
			 return adval; 
		 }
		 
		 
	 }
	 public Iterator<Employee> viewEmployee() throws SQLException
	 {
		 Connection loadcon = ConnectDb.getConnection();
		 PreparedStatement stmt1 = null;
		 PreparedStatement stmt2 = null;
		 PreparedStatement stmt3 = null;
		 ResultSet res = null;
		 ResultSet contractres = null;
		 ResultSet apres = null;
		 String emptype, Houseno;
		String empno;
			String name, designation,sdob , sjoiningDate, Email, sstartDate, stendDate, organisation, reportingTo, Street, Area , City , State;
			Iterator<Employee> viewitr =null;
		 try
			{
							       
			    String sql = "SELECT table1.empno,table1.empname,table1.designation, table1.dob,table1.joiningdate, table1.email, table2.houseno, table2.street, table2.area, table2.city, table2.state FROM \r\n"+
			            "(SELECT generalemployee.empno,generalemployee.empname,generalemployee.designation, generalemployee.dob,generalemployee.joiningdate, generalemployee.email \r\n" + 
			    		"FROM generalemployee\r\n" + 
			    		"WHERE generalemployee.empno NOT IN \r\n" + 
			    		"((SELECT conempno from contractemployee)\r\n" + 
			    		"UNION (SELECT appempno from apprentice))) table1\r\n" +
			    		"LEFT JOIN \r\n"+
			    		"(SELECT * FROM Address ) table2\r\n"+
			    		"ON table1.empno = table2.addempno\r\n"+
			    		"ORDER BY table1.empno;";
			    stmt1 = loadcon.prepareStatement(sql);
			    res = stmt1.executeQuery();
			   
			    
			    EmployeeListFactory elf = new EmployeeListFactory();
			    while(res.next())
			    {
			    emptype = "1";
			    empno = res.getString(1);
			    name = res.getString(2);
			    designation = res.getString(3);
			    sdob = res.getString(4);
			    sjoiningDate = res.getString(5);
			    Email = res.getString(6);
			    Houseno = res.getString(7);
			    Street = res.getString(8);
			    Area = res.getString(9);
			    City = res.getString(10);
			    State = res.getString(11);
			   Address gad1 = new Address(Houseno,Street,Area,City,State);
			    elf.createList("LIST", emptype, empno, name, designation, sdob, sjoiningDate, Email, gad1);
			  
			    }
			    
			    
			    String sql2 = "SELECT generalemployee.empno,generalemployee.empname,generalemployee.designation, generalemployee.dob,generalemployee.joiningdate, generalemployee.email, contractemployee.startdate,contractemployee.enddate, contractemployee.organisation,"
			    		+ "Address.houseno, Address.street, Address.area, Address.city, Address.state\r\n" + 
			    		"FROM (generalemployee\r\n" + 
			    		"RIGHT JOIN contractemployee \r\n" + 
			    		"ON generalemployee.empno = contractemployee.conempno)\r\n" +
			    		"LEFT JOIN address\r\n"+
			    		"ON generalemployee.empno = Address.addempno\r\n"+
			    		"ORDER BY contractemployee.conempno;";
			    stmt2 = loadcon.prepareStatement(sql2);
			    contractres = stmt2.executeQuery();
			  
			    while(contractres.next())
			    {
			    	emptype = "2";
			    	 empno = contractres.getString(1);
					    name = contractres.getString(2);
					    designation = contractres.getString(3);
					    sdob = contractres.getString(4);
					    sjoiningDate = contractres.getString(5);
					    Email = contractres.getString(6);
					    sstartDate = contractres.getString(7);
					    stendDate = contractres.getString(8);
					    organisation = contractres.getString(9);
					    Houseno = contractres.getString(10);
					    Street =contractres.getString(11);
					    Area = contractres.getString(12);
					    City = contractres.getString(13);
					    State = contractres.getString(14);
					   Address cad1 = new Address(Houseno,Street,Area,City,State);
					   elf.createList("LIST", emptype, empno, name, designation, sdob, sjoiningDate, Email, sstartDate, stendDate, organisation, cad1);
			    }
			   
			    
				String sql3 = "SELECT generalemployee.empno,generalemployee.empname,generalemployee.designation, generalemployee.dob,generalemployee.joiningdate, generalemployee.email, apprentice.startdate,apprentice.enddate, apprentice.reportingto,"
						+ "Address.houseno, Address.street, Address.area, Address.city, Address.state\r\n" + 
			    		"FROM (generalemployee\r\n" + 
			    		"RIGHT JOIN apprentice \r\n" + 
			    		"ON generalemployee.empno = apprentice.appempno)\r\n" +
			    		"LEFT JOIN address\r\n"+
			    		"ON generalemployee.empno = Address.addempno\r\n"+
			    		"ORDER BY apprentice.appempno;";
				 stmt3 = loadcon.prepareStatement(sql3);
				 apres = stmt3.executeQuery();
			    
				 while(apres.next())
				    {
				    	emptype = "3";
				    	 empno = apres.getString(1);
						    name = apres.getString(2);
						    designation = apres.getString(3);
						    sdob = apres.getString(4);
						    sjoiningDate = apres.getString(5);
						    Email = apres.getString(6);
						    sstartDate = apres.getString(7);
						    stendDate = apres.getString(8);
						    reportingTo = apres.getString(9);
						    Houseno = apres.getString(10);
						    Street =apres.getString(11);
						    Area = apres.getString(12);
						    City = apres.getString(13);
						    State = apres.getString(14);
						   Address aad1 = new Address(Houseno,Street,Area,City,State);
						   elf.createList("LIST", emptype, empno, name, designation, sdob, sjoiningDate, Email, sstartDate, stendDate, reportingTo, aad1);
				    	
				    }
				    			    
				    //calling iterator on list to print data from database
				   viewitr = elf.callIterator("LIST");
		         }
	        catch(Exception e)
			{
	        	System.out.println(e);
		     }
			 finally
			 {
				 if(!res.next())
				    	res.close();
				 if(!contractres.next())
				    	contractres.close();
				 if(!apres.next())
				    	apres.close();
				 stmt1.close();
				 stmt2.close();
				 stmt3.close();
				 loadcon.close();

			 }
		return viewitr;
	  }
	 
	 
	 public ArrayList<Employee> viewEmployeeList() throws SQLException
	 {
		 Connection loadconview = ConnectDb.getConnection();
		 PreparedStatement stmt1 = null;
		 PreparedStatement stmt2 = null;
		 PreparedStatement stmt3 = null;
		 ResultSet res = null;
		 ResultSet contractres = null;
		 ResultSet apres = null;
		 String emptype, empno, Houseno;
			String name, designation,sdob , sjoiningDate, Email, sstartDate, stendDate, organisation, reportingTo, Street, Area , City , State;
			ArrayList<Employee> viewitr =null;
		 try
			{
							       
			    String sql = "SELECT table1.empno,table1.empname,table1.designation, table1.dob,table1.joiningdate, table1.email, table2.houseno, table2.street, table2.area, table2.city, table2.state FROM \r\n"+
			            "(SELECT generalemployee.empno,generalemployee.empname,generalemployee.designation, generalemployee.dob,generalemployee.joiningdate, generalemployee.email \r\n" + 
			    		"FROM generalemployee\r\n" + 
			    		"WHERE generalemployee.empno NOT IN \r\n" + 
			    		"((SELECT conempno from contractemployee)\r\n" + 
			    		"UNION (SELECT appempno from apprentice))) table1\r\n" +
			    		"LEFT JOIN \r\n"+
			    		"(SELECT * FROM Address ) table2\r\n"+
			    		"ON table1.empno = table2.addempno\r\n"+
			    		"ORDER BY table1.empno;";
			    stmt1 = loadconview.prepareStatement(sql);
			    res = stmt1.executeQuery();
			   
			    
			    EmployeeListFactory elf = new EmployeeListFactory();
			    while(res.next())
			    {
			    emptype = "1";
			    empno = res.getString(1);
			    name = res.getString(2);
			    designation = res.getString(3);
			    sdob = res.getString(4);
			    sjoiningDate = res.getString(5);
			    Email = res.getString(6);
			    Houseno = res.getString(7);
			    Street = res.getString(8);
			    Area = res.getString(9);
			    City = res.getString(10);
			    State = res.getString(11);
			   Address gad1 = new Address(Houseno,Street,Area,City,State);
			    elf.createList("LIST", emptype, empno, name, designation, sdob, sjoiningDate, Email, gad1);
			  
			    }
			    
			    
			    String sql2 = "SELECT generalemployee.empno,generalemployee.empname,generalemployee.designation, generalemployee.dob,generalemployee.joiningdate, generalemployee.email, contractemployee.startdate,contractemployee.enddate, contractemployee.organisation,"
			    		+ "Address.houseno, Address.street, Address.area, Address.city, Address.state\r\n" + 
			    		"FROM (generalemployee\r\n" + 
			    		"RIGHT JOIN contractemployee \r\n" + 
			    		"ON generalemployee.empno = contractemployee.conempno)\r\n" +
			    		"LEFT JOIN Address\r\n"+
			    		"ON generalemployee.empno = Address.addempno\r\n"+
			    		"ORDER BY contractemployee.conempno;";
			    stmt2 = loadconview.prepareStatement(sql2);
			    contractres = stmt2.executeQuery();
			  
			    while(contractres.next())
			    {
			    	emptype = "2";
			    	 empno = contractres.getString(1);
					    name = contractres.getString(2);
					    designation = contractres.getString(3);
					    sdob = contractres.getString(4);
					    sjoiningDate = contractres.getString(5);
					    Email = contractres.getString(6);
					    sstartDate = contractres.getString(7);
					    stendDate = contractres.getString(8);
					    organisation = contractres.getString(9);
					    Houseno = contractres.getString(10);
					    Street =contractres.getString(11);
					    Area = contractres.getString(12);
					    City = contractres.getString(13);
					    State = contractres.getString(14);
					   Address cad1 = new Address(Houseno,Street,Area,City,State);
					   elf.createList("LIST", emptype, empno, name, designation, sdob, sjoiningDate, Email, sstartDate, stendDate, organisation, cad1);
			    }
			   
			    
				String sql3 = "SELECT generalemployee.empno,generalemployee.empname,generalemployee.designation, generalemployee.dob,generalemployee.joiningdate, generalemployee.email, apprentice.startdate,apprentice.enddate, apprentice.reportingto,"
						+ "Address.houseno, Address.street, Address.area, Address.city, Address.state\r\n" + 
			    		"FROM (generalemployee\r\n" + 
			    		"RIGHT JOIN apprentice \r\n" + 
			    		"ON generalemployee.empno = apprentice.appempno)\r\n" +
			    		"LEFT JOIN Address\r\n"+
			    		"ON generalemployee.empno = Address.addempno\r\n"+
			    		"ORDER BY apprentice.appempno;";
				 stmt3 = loadconview.prepareStatement(sql3);
				 apres = stmt3.executeQuery();
			    
				 while(apres.next())
				    {
				    	emptype = "3";
				    	 empno = apres.getString(1);
						    name = apres.getString(2);
						    designation = apres.getString(3);
						    sdob = apres.getString(4);
						    sjoiningDate = apres.getString(5);
						    Email = apres.getString(6);
						    sstartDate = apres.getString(7);
						    stendDate = apres.getString(8);
						    reportingTo = apres.getString(9);
						    Houseno = apres.getString(10);
						    Street =apres.getString(11);
						    Area = apres.getString(12);
						    City = apres.getString(13);
						    State = apres.getString(14);
						   Address aad1 = new Address(Houseno,Street,Area,City,State);
						   elf.createList("LIST", emptype, empno, name, designation, sdob, sjoiningDate, Email, sstartDate, stendDate, reportingTo, aad1);
				    	
				    }
				    			    
				    //calling iterator on list to print data from database
				   viewitr = elf.callList("LIST");
		         }
	        catch(Exception e)
			{
	        	System.out.println(e);
		     }
			 finally
			 {
				 if(!res.next())
				    	res.close();
				 if(!contractres.next())
				    	contractres.close();
				 if(!apres.next())
				    	apres.close();
				 stmt1.close();
				 stmt2.close();
				 stmt3.close();
				 loadconview.close();

			 }
		return viewitr;
	  }

}

