package WebSer;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
public class Address {

	String Houseno,Street, Area , City , State;
	
	@JsonCreator
	public Address(@JsonProperty("Houseno") String Houseno, @JsonProperty("Street") String Street, @JsonProperty("Area") String Area,
	@JsonProperty("City") String City, @JsonProperty("State") String State)
	{
		this.Houseno = Houseno;
		this.Street = Street;
		this.Area = Area;
		this.City = City;
		this.State = State;
		
	}
	
	public String getHouseno() {
		return Houseno;
	}
	
	public void setHouseno(String Houseno) {
		this.Houseno = Houseno;
	}
	public String getStreet() {
		return Street;
	}


	public void setStreet(String Street) {
		this.Street = Street;
	}


	public String getArea() {
		return Area;
	}


	public void setArea(String Area) {
		this.Area = Area;
	}


	public String getCity() {
		return City;
	}


	public void setCity(String City) {
		this.City = City;
	}


	public String getState() {
		return State;
	}


	public void setState(String State) {
		this.State = State;
	}
}

