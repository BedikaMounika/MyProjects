package WebSer;
import java.util.Enumeration;
import java.util.Iterator;

public interface IEmployeeList {

	public Enumeration<Employee> getEmployee();
	public Iterator<Employee> getEmployeeListIterator();
	public Employee getEmployee(String empno);
	public void addEmployee(Employee Employee);
}
