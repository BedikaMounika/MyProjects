package WebSer;


public class ContractEmployee extends Employee{
	

	public String startDate;
	public String endDate;
	public String organisation;

	public ContractEmployee(String emptype,String empno, String name, String designation, String dob, String joiningDate,
			String email, String startDate, String endDate, String organisation , Address Address) 
	{
		super(emptype,empno, name, designation, dob, joiningDate, email,Address);
		// TODO Auto-generated constructor stub
		
		this.startDate = startDate;
		this.endDate = endDate;
		this.organisation = organisation;
	}
	
	
	
	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getOrganisation() {
		return organisation;
	}

	public void setOrganisation(String organisation) {
		this.organisation = organisation;
	}
}
