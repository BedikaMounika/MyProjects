package WebSer;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
@Path("/view")
public class EmpSer 
{
@GET
@Path("/hello")
@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
public String emp()
{
EmployeeDao edao=new EmployeeDao();
ObjectMapper objectMapper = new ObjectMapper();
//Set pretty printing of json
objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
ArrayList<Employee> printitrge = null;
String arrayToJson = null;
try 
{

printitrge = edao.viewEmployeeList();
arrayToJson = objectMapper.writeValueAsString(printitrge);
}
catch (SQLException e) 
{
// TODO Auto-generated catch block
e.printStackTrace();
}
catch (JsonProcessingException e)
{
// TODO Auto-generated catch block
e.printStackTrace();
}
//1. Convert List of Person objects to JSON
System.out.println("Convert List of employee objects to JSON :");
System.out.println(arrayToJson);
return arrayToJson;
} 
@POST
@Path("/score")
@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
@Produces("application/json")
public String emp(GeneralEmployee ge) throws SQLException
{
	EmployeeDao edao=new EmployeeDao();
	ObjectMapper objectMapper = new ObjectMapper();
	//Set pretty printing of json
	objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
	String printitrge;
	String arrayToJson = null;
	try 
	{
	    
		printitrge = edao.saveEmployee(ge.getName(),ge.getDesignation(),ge.getDob(),ge.getJoiningDate(),ge.getEmail(),ge.getAddress()); 
		arrayToJson = objectMapper.writeValueAsString(printitrge);
	    
	}
	catch (SQLException e) 
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	catch (JsonProcessingException e)
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return arrayToJson;
}    	
@DELETE
@Path("/del/{empno}")
@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
@Produces("application/json")
public String emp(@PathParam("empno") String empno) throws SQLException
{
EmployeeDao edao=new EmployeeDao();
ObjectMapper objectMapper = new ObjectMapper();
//Set pretty printing of json
objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
String arrayToJson = null;
try 
{
int printitrge = edao.deleteGeneralEmployee(empno);
arrayToJson = objectMapper.writeValueAsString(printitrge);
}

catch (SQLException e) 
{
// TODO Auto-generated catch block
e.printStackTrace();
}
catch (JsonProcessingException e)
{
// TODO Auto-generated catch block
e.printStackTrace();
}
return arrayToJson;
} 
}