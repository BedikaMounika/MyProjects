package PutExample;
import java.sql.SQLException;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
@Path("hello")
public class PutEmployeeService 
{
	@GET
	@Path("/view/{empno}/{emptype}")
	@Produces(MediaType.APPLICATION_JSON)
	public String getEmployee(@PathParam("empno") String empno, @PathParam("emptype") String emptype)
	{
		
		ObjectMapper objectMapper = new ObjectMapper();
    	//Set pretty printing of json
		objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
		EmployeeDao edao=new EmployeeDao();
		String arrayToJson = null;
	    try
	    {
	    	Employee output = edao.findEmployee(empno, emptype);
			arrayToJson = objectMapper.writeValueAsString(output);	
	    }
	    catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (JsonProcessingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			//1. Convert List of Person objects to JSON
			return arrayToJson;
			
	}   
	
}
 