package Web;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

@Path("/view")
public class EmpService 
{
@GET
@Path("/hello")
@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
public String emp()
{
EmployeeDao edao=new EmployeeDao();
ObjectMapper objectMapper = new ObjectMapper();
//Set pretty printing of json
objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
ArrayList<Employee> printitrge = null;
String arrayToJson = null;
try 
{

printitrge = edao.viewEmployeeList();
arrayToJson = objectMapper.writeValueAsString(printitrge);
}
catch (SQLException e) 
{
// TODO Auto-generated catch block
e.printStackTrace();
}
catch (JsonProcessingException e)
{
// TODO Auto-generated catch block
e.printStackTrace();
}
//1. Convert List of Person objects to JSON
System.out.println("Convert List of employee objects to JSON :");
System.out.println(arrayToJson);
return arrayToJson;

} 
}