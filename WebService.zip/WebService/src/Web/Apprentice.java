package Web;



public class Apprentice extends Employee{

	public String startDate;
	public String endDate;
	public String reportingTo;
	

	public Apprentice(String emptype,String empno, String name, String designation, String dob, String joiningDate, String email, String startDate,
			String endDate, String reportingTo, Address Address) {
		super(emptype,empno, name, designation, dob, joiningDate, email, Address);
		// TODO Auto-generated constructor stub
		
		this.startDate = startDate;
		this.endDate = endDate;
		
		this.reportingTo = reportingTo;


}
	
	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getReportingTo() {
		return reportingTo;
	}

	public void setReportingTo(String reportingTo) {
		this.reportingTo = reportingTo;
	}
}
