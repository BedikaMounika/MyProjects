package Sample;

import java.sql.SQLException;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import Sample.User;
import javax.persistence.Entity;
@Entity
public class EntityFac 
{
	
	public int saveUser(int userId, String Email, String Password, String type) throws SQLException	
   {
   
      EntityManagerFactory emfactory = Persistence.createEntityManagerFactory( "Sample" );
      EntityManager entitymanager = emfactory.createEntityManager( );
      entitymanager.getTransaction( ).begin( );
      User user = new User();
      user.setUserId(userId);
      user.setEmail(Email);
      user.setPassword(Password);
      user.setType(type);
      System.out.println("Entity saved.");
      entitymanager.persist(user);
      entitymanager.getTransaction().commit();
      entitymanager.close();
      emfactory.close( );
      return userId;
     
      
      }
      
     
   }
