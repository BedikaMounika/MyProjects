package Sample;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@Entity
@JsonPropertyOrder("Questions")
public class Questions {
	
	@Id
	 @GeneratedValue(strategy=GenerationType.AUTO)  
	int Type_Id;
	int Number_Of_Questions;
	String Type;
	String Questions;
	String Option_Type;
	String Option1;
	String Option2;
	String Option3;
	String Option4;
	String Option5;
	public int getType_Id() {
		return Type_Id;
	}
	public void setType_Id(int type_Id) {
		Type_Id = type_Id;
	}
	public int getNumber_Of_Questions() {
		return Number_Of_Questions;
	}
	public void setNumber_Of_Questions(int number_Of_Questions) {
		Number_Of_Questions = number_Of_Questions;
	}
	public String getQuestions() {
		return Questions;
	}
	public void setQuestions(String questions) {
		Questions = questions;
	}
	public Questions() {
		super();
	}
	public String getOption1() {
		return Option1;
	}
	public void setOption1(String option1) {
		Option1 = option1;
	}
	public String getOption2() {
		return Option2;
	}
	public void setOption2(String option2) {
		Option2 = option2;
	}
	public String getOption3() {
		return Option3;
	}
	public void setOption3(String option3) {
		Option3 = option3;
	}
	public String getOption4() {
		return Option4;
	}
	public void setOption4(String option4) {
		Option4 = option4;
	}
	public String getOption5() {
		return Option5;
	}
	public void setOption5(String option5) {
		Option5 = option5;
	}
	public String getOption_Type() {
		return Option_Type;
	}
	public void setOption_Type(String option_Type) {
		Option_Type = option_Type;
	}
	public String getType() {
		return Type;
	}
	public void setType(String type) {
		Type = type;
	}
	
	}


