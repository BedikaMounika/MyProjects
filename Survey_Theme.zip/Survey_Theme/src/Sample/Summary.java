package Sample;

import java.io.Serializable;
import java.lang.String;
import java.time.LocalDate;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Entity implementation class for Entity: Summary
 *
 */
@Entity
@JsonPropertyOrder("Summary")

public class Summary implements Serializable {

	   
	@Id
	private int UserId;
	private String Type;
	private int Type_Id;
	private LocalDate Date;
	private static final long serialVersionUID = 1L;

	public Summary() {
		super();
	}   
	public int getUserId() {
		return this.UserId;
	}

	public void setUserId(int UserId) {
		this.UserId = UserId;
	}   
	public String getType() {
		return this.Type;
	}

	public void setType(String Type) {
		this.Type = Type;
	}   
	public int getType_Id() {
		return this.Type_Id;
	}

	public void setType_Id(int Type_Id) {
		this.Type_Id = Type_Id;
	}   
	public LocalDate getDate() {
		return this.Date;
	}

	public void setDate(LocalDate Date) {
		this.Date = Date;
	}
   
}
