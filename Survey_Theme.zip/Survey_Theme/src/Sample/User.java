package Sample;


import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@Entity
@JsonPropertyOrder("User")
public class User {
@Id
@JsonProperty("UserId")
int UserId;
@JsonProperty("Email")
String Email;
@JsonProperty("Password")
String Password;
@JsonProperty("Type")
String Type;


public User() {
super();
}


public int getUserId() {
return UserId;
}
public void setUserId(int userId) {
UserId = userId;
}
public String getEmail() {
return Email;
}
public void setEmail(String Email) {
this.Email = Email;
}

public String getPassword() {
return Password;
}
public void setPassword(String Password) {
this.Password = Password;
}
public String getType() {
	return Type;
}
public void setType(String type) {
	Type = type;
}

}