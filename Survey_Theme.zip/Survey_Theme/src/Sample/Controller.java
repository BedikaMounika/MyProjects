package Sample;
import java.sql.SQLException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

@Path("api")
public class Controller 
{
	@POST
	@Path("/register")
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	@Produces("application/json")
	public String User(User us) throws SQLException
	{
		ObjectMapper objectMapper = new ObjectMapper();
    	//Set pretty printing of json
		objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
		String arrayToJson = null;
		int printitrge;
		try 
		{
			EntityManagerFactory emf = Persistence.createEntityManagerFactory( "Survey_Theme" );
			EntityManager em=emf.createEntityManager();
			em.getTransaction().begin();
			EntityFac jpaq = new EntityFac();
			printitrge = jpaq.saveUser(us.getUserId(), us.getEmail(), us.getPassword(), us.getType());
			arrayToJson = objectMapper.writeValueAsString(printitrge);
		     
		}
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (JsonProcessingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return arrayToJson;
	}    	
	
}


