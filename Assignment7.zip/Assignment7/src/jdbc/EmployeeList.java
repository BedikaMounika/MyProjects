package jdbc;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;


public class EmployeeList implements IEmployeeList{

ArrayList<Employee> al = new ArrayList<Employee>();  
	
	@Override
	public Enumeration<Employee> getEmployee() {
		// TODO Auto-generated method stub
		
		Enumeration<Employee> em = Collections.enumeration(al); 
		return em;
	    
	  }

	@Override
	public Iterator<Employee> getEmployeeListIterator() {
		// TODO Auto-generated method stub
		Iterator<Employee> itr = al.iterator();
		
		return itr;
	}

	@Override
	public Employee getEmployee(int empno) {
		
		// TODO Auto-generated method stub
        Iterator<Employee> itr1 = al.iterator();

            Employee gete = null;
		while(itr1.hasNext())
		{
	      gete = itr1.next();
	      if(gete.empno == empno)
	      {
	    	  break;
	      }
	      
		}
		return gete;
		}
	@Override
	public void addEmployee(Employee Employee) {
		// TODO Auto-generated method stub
		al.add(Employee);
		
	}
}

