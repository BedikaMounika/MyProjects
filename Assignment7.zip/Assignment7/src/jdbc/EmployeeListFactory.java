package jdbc;
import java.time.LocalDate;
import java.util.Iterator;
import java.util.NoSuchElementException;



public class EmployeeListFactory {

	EmployeeList el = new EmployeeList();
	//EmployeeHashList hl = new EmployeeHashList();
	

public Iterator<Employee> callIterator(String listtype)
{
	
	Iterator<Employee> returnprintiter = null;
	if(listtype == "LIST")
	{
	 returnprintiter = el.getEmployeeListIterator();
	 }
	  /*else if(listtype == "HASH")
	   {
		   Iterator<Employee> printhashiter = hl.getEmployeeListIterator();
		   
		   while(printhashiter.hasNext())
			{
				Employee employee = printhashiter.next();
				 System.out.println("Employee details Stored in Hash:");
				   printFunction(employee);
			}
	   }*/
	return returnprintiter;
}


	
	public void createList(String listtype,int emptype,int empno, String name, String designation, String dob, String joiningDate, String email,  Address Address)
	{
		LocalDate dob1 = LocalDate.parse(dob);
		LocalDate joiningDate1 = LocalDate.parse(joiningDate);
		
		if(listtype == "LIST")
		   {
		   	if(emptype == 1)
		   	createEmployee(el,emptype, empno, name, designation, dob1, joiningDate1, email, Address);
		   	
	        }
	  /* else if(listtype == "HASH")
		   {
		   if(emptype == 1)
		   	createEmployee(hl,emptype, empno, name, designation, dob1, joiningDate1, email, Address);
		   	
		   } */
	

	}

	public void createList(String listtype,int emptype,int empno, String name, String designation, String dob, String joiningDate, String email,
		String startDate, String endDate, String changvar, Address Address) throws NoSuchElementException
{
	LocalDate dob1 = LocalDate.parse(dob);
	LocalDate joiningDate1 = LocalDate.parse(joiningDate);
	LocalDate startDate1 = LocalDate.parse(startDate);
	LocalDate endDate1 = LocalDate.parse(endDate);


	
   if(listtype == "LIST")
	   {
	   	   
	   	if(emptype == 2 || emptype == 3)
	   	createEmployee(el,emptype,empno,name, designation, dob1, joiningDate1, email, startDate1, endDate1, changvar, Address);
        }
 /*  else if(listtype == "HASH")
	   {
	   	if(emptype == 2 || emptype == 3)
	   		createEmployee(hl,emptype,empno,name, designation, dob1, joiningDate1, email, startDate1, endDate1, changvar, Address);
	   } */
}


//list type add employee methods
public static IEmployeeList createEmployee(EmployeeList el, int emptype, int empno, String name, String designation, LocalDate dob, LocalDate joiningDate, String email, Address Address)
{
	if(emptype == 1)
	{
		GeneralEmployee g1=new GeneralEmployee(emptype,empno,name,designation,dob,joiningDate,email,Address);
        el.addEmployee(g1);
        
    }
return null;
}

public static IEmployeeList createEmployee(EmployeeList el, int emptype,int empno, String name, String designation, LocalDate dob, LocalDate joiningDate, String email,
		LocalDate startDate, LocalDate endDate, String changvar, Address Address) 
{
	if(emptype == 2)
		{
		ContractEmployee c1=new ContractEmployee(emptype, empno, name, designation, dob, joiningDate, email, startDate, endDate, changvar, Address);
        el.addEmployee(c1);
        }
     else if (emptype == 3)
    	 {
    	 Apprentice a1=new Apprentice(emptype, empno, name, designation, dob, joiningDate, email, startDate, endDate, changvar, Address);
         el.addEmployee(a1);
         }

return null;
}


//Hash type add employee methods
/*
public static IEmployeeList createEmployee(EmployeeHashList hl, int emptype, int empno, String name, String designation, 
		LocalDate dob, LocalDate joiningDate, String email, Address Address)
{
	if(emptype == 1)
		{
		GeneralEmployee g1=new GeneralEmployee(emptype,empno,name,designation,dob,joiningDate,email,Address);
        hl.addEmployee(g1);
        
        }
return null;
}

public static IEmployeeList createEmployee(EmployeeHashList hl, int emptype,int empno, String name, String designation, LocalDate dob, LocalDate joiningDate, String email,
		LocalDate startDate, LocalDate endDate, String changvar, Address Address)
{
	if(emptype == 2)
		{
		ContractEmployee c1=new ContractEmployee(emptype, empno, name, designation, dob, joiningDate, email, startDate, endDate, changvar, Address);
        hl.addEmployee(c1);
         }
     else if (emptype == 3)
    	 {
    	 Apprentice a1=new Apprentice(emptype, empno, name, designation, dob, joiningDate, email, startDate, endDate, changvar, Address);
         hl.addEmployee(a1);
         }
return null;
}
*/
}
