package jdbc;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class VerifyViewOp
 */
@WebServlet("/VerifyViewOp")
public class VerifyViewOp extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VerifyViewOp() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
response.setContentType("text/html");
		
		int emptype =Integer.parseInt(request.getParameter("employee"));
		EmployeeDao edao = new EmployeeDao();
		PrintWriter out = response.getWriter();
		
		try {
			Iterator<Employee> printitrge =edao.viewEmployee();
			Iterator<Employee> printitrce =edao.viewEmployee();
			Iterator<Employee> printitrae =edao.viewEmployee();
			 
			if(emptype == 1)
			{
				out.println("<center>");
				out.println("<h3>Printing General Employee Details:</h3>");
				out.print("<table border='1' width='100%'");  
		        out.print("<tr><th>EmpNo</th><th>EmpName</th><th>Designation</th><th>Dob</th><th>Joining Date</th><th>Email</th><th>HouseNo</th><th>Street</th><th>Area</th><th>City</th><th>State</th></tr>");  
				while(printitrge.hasNext())
				{
					Employee employee = printitrge.next();
					if(employee instanceof GeneralEmployee)
					   {
						GeneralEmployee ge = (GeneralEmployee) employee;
						 out.print("<tr><td>"+ge.getEmpno()+"</td><td>"+ge.getName()+"</td><td>"+ge.getDesignation()+"</td> <td>"+ge.getDob()+"</td><td>"+ge.getJoiningDate()+"</td><td>"+ge.getEmail()+"</td> <td>"+ge.getAdress().Houseno+"</td> <td>"+ge.getAdress().Street+"</td> <td>"+ge.getAdress().Area+"</td> <td>"+ge.getAdress().City+"</td> <td>"+ge.getAdress().State+"</td></tr>");  
					   }
					}
				out.print("</table>");
				
				out.println("<a href='index.jsp'>Main Home Page</a>");
				out.println("<a href='ViewEmp.jsp'>View Page</a>");
				out.println("</center>");
			}
			else if(emptype == 2)
			{
				out.println("<center>");
				out.println("<h3>Printing Contract Employee Details:</h3>");
				out.print("<table border='1' width='100%'");  
		        out.print("<tr><th>EmpNo</th><th>EmpName</th><th>Designation</th><th>Dob</th><th>Joining Date</th><th>Email</th><th>startdate</th><th>enddate</th><th>organisation</th><th>HouseNo</th><th>Street</th><th>Area</th><th>City</th><th>State</th></tr>");  
				while(printitrce.hasNext())
				{
					Employee employee = printitrce.next();
					if(employee instanceof ContractEmployee)
					   {
						 ContractEmployee ce = (ContractEmployee) employee;
						 out.print("<tr><td>"+ce.getEmpno()+"</td><td>"+ce.getName()+"</td><td>"+ce.getDesignation()+"</td> <td>"+ce.getDob()+"</td><td>"+ce.getJoiningDate()+"</td><td>"+ce.getEmail()+"</td> <td>"+ce.getStartDate()+"</td> <td>"+ce.getEndDate()+"</td> <td>"+ce.getOrganisation()+"</td> <td>"+ce.getAdress().Houseno+"</td> <td>"+ce.getAdress().Street+"</td> <td>"+ce.getAdress().Area+"</td> <td>"+ce.getAdress().City+"</td> <td>"+ce.getAdress().State+"</td></tr>");  
					   }
					}
				out.print("</table>");
				out.println("<a href='index.jsp'>Main Home Page</a>");
				out.println("<a href='ViewEmp.jsp'>View Page</a>");
				out.println("</center>");
			}
			else if(emptype == 3)
			{
				out.println("<center>");
				out.println("<h3>Printing Apprentice Employee Details:</h3>");
				out.print("<table border='1' width='100%'");  
		        out.print("<tr><th>EmpNo</th><th>EmpName</th><th>Designation</th><th>Dob</th><th>Joining Date</th><th>Email</th><th>startdate</th><th>enddate</th><th>organisation</th><th>HouseNo</th><th>Street</th><th>Area</th><th>City</th><th>State</th></tr>");  
				while(printitrae.hasNext())
				{
					Employee employee = printitrae.next();
					if(employee instanceof Apprentice)
					   {
						 Apprentice ae = (Apprentice) employee;
						 out.print("<tr><td>"+ae.getEmpno()+"</td><td>"+ae.getName()+"</td><td>"+ae.getDesignation()+"</td> <td>"+ae.getDob()+"</td><td>"+ae.getJoiningDate()+"</td><td>"+ae.getEmail()+"</td> <td>"+ae.getStartDate()+"</td> <td>"+ae.getEndDate()+"</td> <td>"+ae.getReportingTo()+"</td> <td>"+ae.getAdress().Houseno+"</td> <td>"+ae.getAdress().Street+"</td> <td>"+ae.getAdress().Area+"</td> <td>"+ae.getAdress().City+"</td> <td>"+ae.getAdress().State+"</td></tr>");  
					   }
					}
				out.print("</table>");
				out.println("<a href='index.jsp'>Main Home Page</a>");
				out.println("<a href='ViewEmp.jsp'>View Page</a>");
				out.println("</center>");
			}
			else if(emptype == 4)
			{
				out.println("<center>");
				out.println("<h3>Printing All Types of Employees Details:</h3>");
				out.println("<h3>Printing General Employee Details:</h3>");
				out.print("<table border='1' width='100%'");  
		        out.print("<tr><th>EmpNo</th><th>EmpName</th><th>Designation</th><th>Dob</th><th>Joining Date</th><th>Email</th><th>HouseNo</th><th>Street</th><th>Area</th><th>City</th><th>State</th></tr>");  
				while(printitrge.hasNext())
				{
					Employee employee = printitrge.next();
					if(employee instanceof GeneralEmployee)
					   {
						GeneralEmployee ge = (GeneralEmployee) employee;
						 out.print("<tr><td>"+ge.getEmpno()+"</td><td>"+ge.getName()+"</td><td>"+ge.getDesignation()+"</td> <td>"+ge.getDob()+"</td><td>"+ge.getJoiningDate()+"</td><td>"+ge.getEmail()+"</td> <td>"+ge.getAdress().Houseno+"</td> <td>"+ge.getAdress().Street+"</td> <td>"+ge.getAdress().Area+"</td> <td>"+ge.getAdress().City+"</td> <td>"+ge.getAdress().State+"</td></tr>");  
					   }
					}
				out.print("</table>"); 
				
				out.println("<h3>Printing Contract Employee Details:</h3>");
				out.print("<table border='1' width='100%'");  
		        out.print("<tr><th>EmpNo</th><th>EmpName</th><th>Designation</th><th>Dob</th><th>Joining Date</th><th>Email</th><th>startdate</th><th>enddate</th><th>organisation</th><th>HouseNo</th><th>Street</th><th>Area</th><th>City</th><th>State</th></tr>");  
				while(printitrce.hasNext())
				{
					Employee employee = printitrce.next();
					if(employee instanceof ContractEmployee)
					   {
						 ContractEmployee ce = (ContractEmployee) employee;
						 out.print("<tr><td>"+ce.getEmpno()+"</td><td>"+ce.getName()+"</td><td>"+ce.getDesignation()+"</td> <td>"+ce.getDob()+"</td><td>"+ce.getJoiningDate()+"</td><td>"+ce.getEmail()+"</td> <td>"+ce.getStartDate()+"</td> <td>"+ce.getEndDate()+"</td> <td>"+ce.getOrganisation()+"</td> <td>"+ce.getAdress().Houseno+"</td> <td>"+ce.getAdress().Street+"</td> <td>"+ce.getAdress().Area+"</td> <td>"+ce.getAdress().City+"</td> <td>"+ce.getAdress().State+"</td></tr>");  
					   }
					}
				out.print("</table>");
				
				out.println("<h3>Printing Apprentice Employee Details:</h3>");
				out.print("<table border='1' width='100%'");  
		        out.print("<tr><th>EmpNo</th><th>EmpName</th><th>Designation</th><th>Dob</th><th>Joining Date</th><th>Email</th><th>startdate</th><th>enddate</th><th>organisation</th><th>HouseNo</th><th>Street</th><th>Area</th><th>City</th><th>State</th></tr>");  
				while(printitrae.hasNext())
				{
					Employee employee = printitrae.next();
					if(employee instanceof Apprentice)
					   {
						 Apprentice ae = (Apprentice) employee;
						 out.print("<tr><td>"+ae.getEmpno()+"</td><td>"+ae.getName()+"</td><td>"+ae.getDesignation()+"</td> <td>"+ae.getDob()+"</td><td>"+ae.getJoiningDate()+"</td><td>"+ae.getEmail()+"</td> <td>"+ae.getStartDate()+"</td> <td>"+ae.getEndDate()+"</td> <td>"+ae.getReportingTo()+"</td> <td>"+ae.getAdress().Houseno+"</td> <td>"+ae.getAdress().Street+"</td> <td>"+ae.getAdress().Area+"</td> <td>"+ae.getAdress().City+"</td> <td>"+ae.getAdress().State+"</td></tr>");  
					   }
					}
				out.print("</table>");
				
				out.println("<a href='index.jsp'>Main Home Page</a>");
				out.println("<a href='ViewEmp.jsp'>View Page</a>");
				out.println("</center>");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(out == null)
				out.close();
		}
	}

}
