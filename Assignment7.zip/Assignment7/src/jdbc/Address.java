package jdbc;
public class Address {

	int Houseno;
	String Street, Area , City , State;
	
	public Address(int Houseno, String Street, String Area, String City, String State)
	{
		this.Houseno = Houseno;
		this.Street = Street;
		this.Area = Area;
		this.City = City;
		this.State = State;
		
	}
	
	public int getHouseno() {
		return Houseno;
	}
	
	public void setHouseno(int Houseno) {
		this.Houseno = Houseno;
	}
	public String getStreet() {
		return Street;
	}


	public void setStreet(String Street) {
		this.Street = Street;
	}


	public String getArea() {
		return Area;
	}


	public void setArea(String Area) {
		this.Area = Area;
	}


	public String getCity() {
		return City;
	}


	public void setCity(String City) {
		this.City = City;
	}


	public String getState() {
		return State;
	}


	public void setState(String State) {
		this.State = State;
	}
}
